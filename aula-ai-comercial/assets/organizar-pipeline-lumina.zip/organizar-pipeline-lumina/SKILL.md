---
name: organizar-pipeline-lumina
description: Recebe uma planilha bruta de pipeline comercial da Lumina (exportada do CRM ou mantida manualmente em Excel) e devolve as oportunidades classificadas nos 5 estágios padrão do pipeline (Lead, Qualificado, Proposta, Negociação, Fechado) em formato tabular no chat — sem gerar artefatos, otimizada para consumo mínimo de créditos no plano gratuito do Claude. Use sempre que o usuário enviar uma planilha bruta de oportunidades comerciais da Lumina e pedir para organizar, estruturar, classificar nos estágios ou preparar para análise de pipeline.

---

# organizar-pipeline-lumina

Skill que padroniza uma planilha bruta de pipeline comercial da Lumina, classifica cada oportunidade nos 5 estágios padrão definidos no `estagios-do-pipeline-lumina.md`, e devolve **4 tabelas markdown agradáveis no chat** (sem gerar artefatos para download). Output otimizado para consumo mínimo de créditos.

**Filosofia:** organização determinística com output enxuto. A Skill NUNCA inventa dados — apenas lê, padroniza, classifica e exibe em tabelas legíveis. **Sem code execution, sem geração de arquivos.** Aluno do plano gratuito termina a AP02 gastando exatamente 1 mensagem.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os arquivos de contexto carregados no Project Comercial Lumina:

1. **`plano-de-vendas-lumina.md`** — define os 4 canais, ICP por canal, ticket médio esperado, equipe comercial
2. **`estagios-do-pipeline-lumina.md`** — define os 5 estágios, critérios de avanço, SLA por estágio, sinais de esfriamento

Se um dos dois arquivos não estiver carregado, **pare e avise o usuário** — sem esses arquivos a Skill opera às cegas.

Após carregar, escreva uma linha curta confirmando:

> ✅ Plano de vendas + estágios do pipeline Lumina carregados. Analisando a planilha agora.

---

## PASSO 1 — Receber e inspecionar a planilha bruta

O usuário vai anexar uma planilha `.xlsx` ou `.csv`. Identifique as colunas equivalentes às colunas padrão Lumina (ID, Nome, Canal, Vendedor, Estágio, Valor, Data de entrada, Data última interação, Próxima ação, Observações). Se houver ambiguidade, pergunte.

**Validações iniciais — apresentar em 1 parágrafo curto antes das tabelas:**

> 📊 **Pipeline detectado:** [N] oportunidades ativas, somando **R$ [X]**, cobrindo o período de **[data1] a [data2]**.

---

## PASSO 2 — Classificar e padronizar

Para cada oportunidade:

### Normalizar "Estágio atual" para 5 estágios padrão

- **Lead** ← novo, novo lead, recém-chegado, prospect, MQL, lead, raw lead, contato inicial
- **Qualificado** ← qualificado, SQL, qualificado pelo SDR, aprovado, em qualificação
- **Proposta** ← proposta, proposal, em proposta, proposta enviada, cotação enviada
- **Negociação** ← negociação, em negociação, fechamento, em fechamento, ajustes
- **Fechado** ← fechado, ganho, won, closed won, vendido, contrato assinado

### Normalizar "Canal" para 4 canais padrão

- **B2B Distribuidores** ← B2B, distribuidor, revenda, atacado
- **Loja SP** ← Loja SP, Sao Paulo, SP, Loja Vila Madalena
- **Loja RJ** ← Loja RJ, Rio de Janeiro, RJ, Loja Ipanema
- **E-commerce** ← E-commerce, online, ecommerce, web, marketplace

### Calcular Dias parado e Status SLA

- `dias_parado = data_atual_do_snapshot - data_última_interação`
- **Status SLA:**
  - 🟢 **Dentro do SLA** se `dias_parado < SLA preocupante` do estágio
  - 🟡 **Atenção** se `dias_parado` está no limite (-1 ou exatamente no SLA)
  - 🔴 **SLA estourado** se `dias_parado > SLA preocupante`

**SLAs preocupantes (de `estagios-do-pipeline-lumina.md`):**

| Estágio | SLA Preocupante |
|---|---|
| Lead | 4+ dias |
| Qualificado | 8+ dias |
| Proposta | 15+ dias |
| Negociação | 11+ dias |

---

## PASSO 3 — Output em 4 tabelas markdown agradáveis (TUDO NO CHAT)

**REGRA CRÍTICA:** NÃO gerar artefato `.xlsx`. NÃO usar code execution. Apresentar tudo no chat em tabelas markdown formatadas.

### Tabela 1 — Distribuição por Estágio

Formato:

```
### 🎯 Distribuição por Estágio

| Estágio | # Oportunidades | Valor (R$) | % do pipeline |
|---|---:|---:|---:|
| 🟦 Lead | N | R$ X | N,N% |
| 🟪 Qualificado | N | R$ X | N,N% |
| 🟨 Proposta | N | R$ X | N,N% |
| 🟧 Negociação | N | R$ X | N,N% |
| 🟩 Fechado (última semana) | N | R$ X | N,N% |
| **TOTAL ATIVO** | **N** | **R$ X** | **100%** |
```

**Notas de formatação:**
- Emojis quadrados coloridos antes do nome do estágio para hierarquia visual rápida
- Alinhamento de números à direita usando `---:`
- Linha TOTAL em negrito separando ativos vs fechados
- Excluir do total ativo as oportunidades já fechadas

### Tabela 2 — Distribuição por Canal

```
### 📍 Distribuição por Canal

| Canal | # Oportunidades | Valor (R$) | % do pipeline | Ticket médio |
|---|---:|---:|---:|---:|
| • B2B Distribuidores | N | R$ X | N,N% | R$ X |
| • Loja SP | N | R$ X | N,N% | R$ X |
| • Loja RJ | N | R$ X | N,N% | R$ X |
| • E-commerce | N | R$ X | N,N% | R$ X |
```

**Nota importante:** E-commerce normalmente não usa estes 5 estágios (transação imediata). Se aparecer, apenas contabilizar — não tentar classificar.

### Tabela 3 — Distribuição por Vendedor

```
### 👥 Distribuição por Vendedor

| Vendedor | # Oportunidades | Valor (R$) |
|---|---:|---:|
| Pedro Almeida (SP) | N | R$ X |
| Mariana Costa (SP) | N | R$ X |
| Rafael Pereira (RJ) | N | R$ X |
| Juliana Santos (RJ) | N | R$ X |
| Camila Oliveira (E-com) | N | R$ X |
| Bruno Carvalho (B2B) | N | R$ X |
```

### Tabela 4 — Top Oportunidades 🔴 SLA Estourado

```
### 🔴 Oportunidades acima do SLA (atenção urgente)

| ID | Cliente | Canal | Estágio | Valor | Dias parado | Vendedor |
|---|---|---|---|---:|---:|---|
| ID | Nome | Canal | Estágio | R$ X | N dias 🔴 | Vendedor |
...
```

**Notas:**
- Listar todas as oportunidades 🔴 (não limitar a 5) — informação crítica para o coordenador
- Ordenar por valor decrescente
- Manter colunas enxutas (sem "próxima ação" — vai aparecer no diagnóstico da AP03)

### Mensagem de encerramento

Após as 4 tabelas, escrever 2 linhas finais:

> ⚠️ **Total de oportunidades em alerta:** [N] 🔴 (SLA estourado) + [M] 🟡 (atenção). Valor em risco: **R$ [X]**.
>
> ✅ Pipeline organizado. **Próximo passo:** acione a Skill `diagnosticar-pipeline-lumina` nesta mesma conversa para gerar o diagnóstico narrativo com os 3 leads urgentes, scripts copiáveis, tendências e ação recomendada.

---

## Tom e estilo

- **Português brasileiro executivo, direto**
- **Sempre tabular** para dados estruturados
- **Valores monetários no padrão brasileiro:** `R$ 18.500`
- **Percentuais com 1 casa decimal:** `35,2%`
- **Dias sempre como número inteiro:** `11 dias`
- **Emojis:**
  - Indicadores de SLA: 🟢 🟡 🔴
  - Cabeçalhos de tabela: 🎯 📍 👥 🔴
  - Hierarquia de estágio: 🟦 🟪 🟨 🟧 🟩
  - Marcador de canal: •
  - Alertas: ⚠️ ✅ 📊

---

## Não faça

- **NÃO gere artefato `.xlsx`** — toda a saída é no chat
- **NÃO use code execution** — apenas markdown
- **NÃO invente oportunidades** que não estavam na planilha
- **NÃO classifique como "perdidas"** sem instrução explícita
- **NÃO faça análise interpretativa** ou recomendação (isso é trabalho da Skill `diagnosticar-pipeline-lumina`)
- **NÃO consolide duplicatas** sem confirmar com o usuário
- **NÃO altere valores monetários ou datas**
- **NÃO use ASCII art elaborado** (cabeçalhos com bordas duplas) — pode quebrar renderização
- **NÃO encerre sem direcionar para a próxima Skill** (`diagnosticar-pipeline-lumina`)

---

## Tratamento de erros

- **Plano de vendas ou estágios faltando:** pare e oriente o usuário a carregar os arquivos no Project
- **Planilha sem coluna identificável de estágio:** pergunte qual coluna usar antes de prosseguir
- **Planilha com mais de 200 oportunidades:** alerte que está acima do volume Lumina (40-60) e confirme se é o snapshot correto
- **Planilha vazia ou só com cabeçalhos:** alerte e peça nova planilha

---

## Exemplo de comportamento esperado

**Input do usuário:**
> "Anexei a planilha de pipeline atualizada de segunda 13/out. Por favor organize."

**Output esperado (TUDO NO CHAT, SEM ARTEFATO):**

1. Linha de confirmação: "✅ Plano de vendas + estágios do pipeline Lumina carregados. Analisando a planilha agora."
2. Validação inicial: "📊 Pipeline detectado: 48 oportunidades ativas, somando R$ 467.250, cobrindo o período de 18/set a 13/out."
3. As 4 tabelas markdown (Estágio, Canal, Vendedor, Top SLA Estourado)
4. Mensagem de encerramento direcionando para a próxima Skill

**O aluno gasta exatamente 1 mensagem.**
