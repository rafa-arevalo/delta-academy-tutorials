---
name: gerar-briefing-lumina
description: Lê o pipeline organizado e o diagnóstico já gerados nesta conversa pelas Skills anteriores (organizar-pipeline-lumina e diagnosticar-pipeline-lumina), consulta a identidade visual carregada no Project, e produz o Briefing Semanal do Pipeline em DOIS CAMINHOS possíveis — Caminho A (HTML autocontido, recomendado para plano pago) ou Caminho B (texto enriquecido no chat, recomendado para plano gratuito). A Skill SEMPRE pergunta ao usuário qual caminho seguir antes de gerar. Use sempre que o usuário tiver gerado o diagnóstico do pipeline e pedir para criar o briefing, gerar a peça visual, montar o relatório semanal, fechar o material da semana ou compilar o briefing comercial.

---

# gerar-briefing-lumina

Skill que produz o Briefing Semanal do Pipeline da Lumina em **dois caminhos** dependendo da preferência do usuário:

- **Caminho A** — Briefing visual em HTML autocontido (artefato para download, abre no navegador, otimizado para impressão)
- **Caminho B** — Briefing textual enriquecido no próprio chat (sem artefato, consumo mínimo de créditos)

A Skill **SEMPRE pergunta ao usuário qual caminho seguir antes de gerar**, com orientação clara sobre o consumo de créditos de cada opção.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os arquivos de contexto carregados no Project Comercial Lumina:

1. **`identidade-visual-lumina.md`** — paleta de cores, tipografia, princípios de design
2. **`plano-de-vendas-lumina.md`** — metas e contexto comercial para enriquecer o briefing se relevante

Se o `identidade-visual-lumina.md` não estiver disponível, **pare e avise o usuário** — sem a identidade visual carregada, o briefing sairia genérico, sem o DNA da marca.

Após carregar, escreva uma linha curta confirmando:

> ✅ Identidade visual Lumina carregada. Pronto para gerar briefing.

---

## PASSO 1 — Identificar pipeline organizado e diagnóstico na conversa

Localize na conversa atual:

1. **Pipeline estruturado** — 4 tabelas geradas pela Skill `organizar-pipeline-lumina`
2. **Diagnóstico narrativo** — 5 blocos gerados pela Skill `diagnosticar-pipeline-lumina`

Se um dos dois estiver faltando, **pare e oriente o usuário**:

- Sem pipeline organizado → "Acione primeiro a Skill `organizar-pipeline-lumina` antes desta."
- Sem diagnóstico → "Acione primeiro a Skill `diagnosticar-pipeline-lumina` antes desta."

Se ambos estiverem presentes mas forem de semanas diferentes, use o **mais recente** e avise.

---

## PASSO 2 — PERGUNTAR ao usuário qual caminho seguir (OBRIGATÓRIO)

**NUNCA pular este passo.** Antes de gerar qualquer coisa, apresentar exatamente esta pergunta:

```
Antes de gerar o briefing, preciso saber qual formato você quer:

📄 **CAMINHO A — Briefing em HTML autocontido** (artefato visual)
- Arquivo HTML único pronto para abrir no navegador
- Paleta wellness Lumina, tipografia Fraunces + Inter
- 6 blocos visuais com cards, indicadores e botões "Copiar script"
- Print-friendly (Ctrl+P gera PDF perfeito)
- **⚠️ Consome mais créditos** — usa code execution para gerar o HTML
- **Recomendado para alunos com plano pago do Claude**

💬 **CAMINHO B — Briefing em texto enriquecido** (no próprio chat)
- 6 blocos formatados em markdown enriquecido (tabelas, blockquotes, scripts em blocos de código copiáveis)
- Sem artefato, sem code execution
- **✅ Consumo mínimo de créditos** — gera em poucos segundos
- **Recomendado para alunos com plano gratuito do Claude** (preserva créditos para outras tarefas)

Qual caminho você quer? Responda apenas "A" ou "B".
```

**Aguardar a resposta do usuário** antes de prosseguir.

Se o usuário disser "A": ir para PASSO 3A
Se o usuário disser "B": ir para PASSO 3B
Se a resposta for ambígua: pedir novamente "A" ou "B" sem prosseguir.

---

## PASSO 3A — CAMINHO A: Renderizar como HTML autocontido

Gerar o briefing como **artefato HTML único** com a seguinte estrutura:

### Estrutura HTML

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Briefing Semanal — Lumina · Semana de [data]</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <style>/* CSS inline */</style>
</head>
<body>
  <!-- 6 blocos -->
  <script>/* JavaScript inline para botões "Copiar" */</script>
</body>
</html>
```

### Paleta de cores (CSS variables)

```css
:root {
  --bg: #FBF9F5;          /* Branco quente neutro */
  --musgo: #5C7A5A;       /* Verde-musgo (cor estrutural) */
  --coral: #C97A5A;       /* Coral terroso (acentos) */
  --taupe: #8A857D;       /* Cinza-taupe (texto secundário) */
  --verde-claro: #D4DDC9; /* Verde-claro pálido */
  --champagne: #D1AA53;   /* Dourado champagne */
  --texto: #2C2C2A;
}
```

### Tipografia

- Títulos: `font-family: 'Fraunces', Georgia, serif;` — pesos 400/500/600
- Corpo: `font-family: 'Inter', system-ui, sans-serif;` — pesos 400/500
- Tamanhos generosos no desktop, escalando para mobile via `clamp()`

### Os 6 blocos visuais

**Bloco 1 — Cabeçalho institucional**
- Logo SVG inline da Lumina (círculo verde-musgo vazado + tipografia "lumina" lowercase em Fraunces)
- Título: "Briefing Semanal do Pipeline"
- Subtítulo: dia da semana + data
- Saudação: "Bom dia, Carolina."
- Indicador de humor (🟢/🟡/🔴) com texto explicativo de 1 linha

**Bloco 2 — Foto da semana (2 sub-blocos)**
- 2A: Visão por Estágio — 5 cards horizontais (Lead → Qualificado → Proposta → Negociação → Fechado), cada um com # oportunidades, valor R$, comparativo (▲ verde, ▼ coral, ▬ cinza)
- 2B: Visão por Canal — tabela limpa com Canal | # ativos | Valor R$ | vs semana anterior

**Bloco 3 — 3 leads que precisam de atenção HOJE**
- Cada lead como card editorial com badge de urgência (🔴/🟡), ID + Nome + Canal + Valor, Vendedor + Estágio + Dias parado, Diagnóstico do gargalo, **Script copiável com botão "Copiar script" funcional via JavaScript inline**

**Bloco 4 — Tendências detectadas**
- 3 sub-blocos visuais (canal acelerando / canal desacelerando / estágio travado)
- Cada um: ícone + movimento quantificado em destaque + root cause + ação sugerida com ícone de seta

**Bloco 5 — Oportunidade da semana**
- Card destacado com fundo gradiente sutil (verde-claro pálido → branco quente)
- Ícone 💡 + frase Fraunces grande + 2-3 frases de contexto + ação sugerida

**Bloco 6 — Ação recomendada da semana**
- Background verde-musgo escuro + texto branco quente
- Frase imperativa central em Fraunces grande
- 3 bullets cronológicos: Hoje, Até quarta, Antes de sexta

### JavaScript inline para botões "Copiar script"

```javascript
document.querySelectorAll('.copy-script-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = document.querySelector(btn.dataset.target);
    navigator.clipboard.writeText(target.textContent.trim());
    const original = btn.textContent;
    btn.textContent = 'Copiado ✓';
    btn.style.background = 'var(--musgo)';
    setTimeout(() => {
      btn.textContent = original;
      btn.style.background = '';
    }, 2000);
  });
});
```

### Print-friendly

`@media print` com margens A4, cores preservadas (`-webkit-print-color-adjust: exact`), quebras de página antes do Bloco 4 e Bloco 6, e ocultar botões "Copiar script" no print.

### Sem dependências externas

- Sem `<link>` para CSS externo (exceção: Google Fonts CDN)
- Sem JavaScript de servidor — apenas script inline
- Sem imagens externas (logo é SVG inline)

### Output do Caminho A

1. Mensagem curta no chat:

> ✅ **Briefing Semanal Lumina · Semana de [data] gerado em HTML.**
>
> Arquivo HTML autocontido pronto para download. Abra no navegador para visualizar — os scripts dos 3 leads urgentes têm botão "Copiar" funcional. Para imprimir ou exportar como PDF, use Ctrl+P (Cmd+P no Mac).

2. Artefato HTML com nome `briefing-lumina-semana-[data].html`

---

## PASSO 3B — CAMINHO B: Renderizar 6 blocos no próprio chat (texto enriquecido)

**REGRA CRÍTICA:** NÃO gerar artefato HTML. NÃO usar code execution. Apresentar tudo no chat com markdown enriquecido (tabelas, blockquotes, blocos de código para scripts copiáveis).

### Cabeçalho

```
# 📋 Briefing Semanal do Pipeline — Lumina

**Semana de [data]** · Boa segunda-feira, Carolina.

[🟢/🟡/🔴] **Humor do pipeline:** [SAUDÁVEL/ATENÇÃO/ALERTA] — [frase de 1 linha resumindo o estado]
```

### Bloco 1 — Cabeçalho contextual

Já coberto no cabeçalho acima.

### Bloco 2 — Foto da semana

```
## 📸 Foto da semana

### Visão por Estágio (vs semana anterior)

| Estágio | # Atual | Valor | vs Semana Anterior |
|---|---:|---:|---|
| 🟦 Lead | 8 | R$ 62.650 | ▲ +14% |
| 🟪 Qualificado | 10 | R$ 99.500 | ▬ estável |
| 🟨 Proposta | 12 | R$ 132.700 | ▲ +20% |
| 🟧 Negociação | 12 | R$ 117.400 | ▲ +20% |
| 🟩 Fechado (semana) | 6 | R$ 55.800 | ▼ -25% |

### Visão por Canal

| Canal | # Ativos | Valor | vs Semana Anterior |
|---|---:|---:|---|
| B2B Distribuidores | 18 | R$ 285.500 | ▲ +12% |
| Loja SP | 12 | R$ 68.900 | ▼ -8% |
| Loja RJ | 11 | R$ 47.300 | ▬ estável |
| E-commerce | 1 | R$ 10.550 | ▲ novo |
```

### Bloco 3 — 3 leads que precisam de atenção HOJE

Mesma estrutura do diagnóstico (AP03), mas reapresentar aqui no briefing. Cada lead em mini-card:

```
## 🎯 3 leads que precisam de atenção HOJE

---

### 🔴 Lead 1 · [ID] · [Nome do cliente]

> **Canal:** [Canal] | **Vendedor:** [Vendedor] | **Estágio:** [Estágio] | **Valor:** **R$ [X]** | **Dias parado:** [N] dias

**Diagnóstico:** [1-2 frases]

**Script de aproximação:**

​```
[Script de 60-80 palavras em tom Lumina]
​```

---

### 🔴 Lead 2 · [...]

### 🔴 Lead 3 · [...]
```

### Bloco 4 — Tendências detectadas

```
## 📈 Tendências detectadas

### 🚀 Canal acelerando

> **[Canal X] +N% em valor** vs semana passada.
>
> **Root cause provável:** [explicação]
>
> **→ Ação:** [ação concreta]

### 📉 Canal desacelerando

> **[Canal Y] -N% em volume** vs semana passada.
>
> **Root cause provável:** [explicação]
>
> **→ Ação:** [ação concreta]

### 🚧 Estágio travado

> **[Estágio Z] tem N% das oportunidades acima do SLA.**
>
> **Root cause provável:** [explicação]
>
> **→ Ação coletiva:** [ação concreta]
```

### Bloco 5 — Oportunidade da semana

```
## 💡 Oportunidade da semana

> **[Padrão identificado em 1 frase impactante]**
>
> [Parágrafo de 2-3 frases com números específicos]
>
> **→ Ação sugerida:** [ação concreta]
```

### Bloco 6 — Ação recomendada da semana

```
## ✅ Ação recomendada da semana

> **Esta semana, foque em [X].**

**Cronograma sugerido:**

1. **Hoje (segunda):** [ação específica]
2. **Até quarta:** [ação específica]
3. **Antes de sexta:** [ação específica]
```

### Mensagem de encerramento

```
---

✅ Briefing completo. Você pode copiar os scripts dos 3 leads urgentes diretamente dos blocos de código acima (botão "Copiar" aparece ao passar o mouse).

**Próximo passo:** estabeleça sua rotina semanal — abra o Project Comercial Lumina toda segunda-feira pela manhã, atualize a planilha do pipeline e rode as 3 Skills em sequência. Em 5 minutos você tem o briefing completo da semana.
```

---

## Tom e estilo (CAMINHOS A e B)

- **Visual minimalismo wellness premium** — fresca, sofisticada, energética sem ser agressiva
- **Espaço negativo é protagonista** (no HTML)
- **Dados acima de ornamentos** — números são o foco
- **Linhas finas, nunca grossas** (no HTML)
- **Sem grade visível em tabelas** (no HTML)
- **Hierarquia por espaçamento, não por cor extrema**
- **Sem sombras pesadas, gradientes complexos ou ornamentos**

---

## Observação para o usuário ao final do Caminho A ou Caminho B

Após o output do briefing (em ambos os caminhos), adicionar como nota final:

```
---

> 💎 **Próximo nível (plano pago):** se você tem acesso ao plano pago do Claude, pode usar **Live Artifacts** conectados a planilhas no seu computador ou Google Drive. Toda vez que você atualizar a planilha de pipeline, o briefing HTML se atualiza sozinho — sem precisar acionar a Skill novamente. É a evolução natural quando você quiser zero clique manual na rotina semanal.
```

---

## Não faça (CAMINHO A — HTML)

- Não inventar conteúdo que não esteja no pipeline ou diagnóstico
- Não usar JavaScript para carregar dados externamente
- Não usar CSS externo via `<link>` (exceção: Google Fonts CDN)
- Não usar cores fora da paleta Lumina
- Não usar sombras pesadas ou gradientes complexos
- Não preencher a página inteira — espaço negativo é protagonista

## Não faça (CAMINHO B — Texto)

- Não gerar artefato — toda a saída é no chat
- Não usar code execution
- Não usar ASCII art elaborado

## Não faça (GERAL)

- **NÃO pular o PASSO 2** (pergunta sobre o caminho) — sempre perguntar primeiro
- **NÃO escolher o caminho sozinho** — esperar resposta do usuário
- **NÃO duplicar informações entre blocos** dentro do briefing
- **NÃO inventar humor do pipeline sem base no diagnóstico**

---

## Tratamento de erros

- **Identidade visual faltando:** pare e oriente a carregar `identidade-visual-lumina.md` no Project
- **Pipeline organizado faltando:** pare e oriente a acionar `organizar-pipeline-lumina` antes
- **Diagnóstico faltando:** pare e oriente a acionar `diagnosticar-pipeline-lumina` antes
- **Usuário não responde A nem B:** pergunte novamente, sem prosseguir
- **Pipeline e diagnóstico de semanas diferentes:** use o mais recente e avise

---

## Exemplo de comportamento esperado

**Input do usuário (na mesma conversa onde pipeline organizado e diagnóstico já foram gerados):**
> "Agora gere o briefing semanal."

**Output esperado:**

1. "✅ Identidade visual Lumina carregada. Pronto para gerar briefing."
2. Apresentar o **PASSO 2 — pergunta sobre caminho A ou B** (com orientação completa sobre consumo de créditos de cada um)
3. **Aguardar resposta do usuário**
4. Se "A": gerar artefato HTML autocontido + nota Live Artifacts
5. Se "B": gerar 6 blocos no chat em texto enriquecido + nota Live Artifacts

**O aluno gasta exatamente 1 mensagem em qualquer caminho.**
