---
name: diagnosticar-pipeline-lumina
description: Lê o pipeline organizado pela Skill organizar-pipeline-lumina (mesma conversa), compara com o snapshot da semana anterior, consulta o histórico de fechados, e produz um diagnóstico narrativo executivo em 5 blocos no próprio chat — sem gerar artefatos, otimizado para consumo mínimo de créditos no plano gratuito do Claude. Use sempre que o usuário tiver organizado o pipeline com a Skill anterior e pedir análise, diagnóstico, leitura semanal, identificação de leads em risco, ou material para a reunião de pipeline review.

---

# diagnosticar-pipeline-lumina

Skill que produz o diagnóstico semanal do pipeline comercial da Lumina em 5 blocos no padrão Executive Summary, **TUDO renderizado no próprio chat** — sem gerar artefatos de download. Output otimizado para consumo mínimo de créditos.

**Filosofia:** diagnóstico materializado, com nome e sobrenome. Cada lead urgente tem **script de aproximação em bloco de código copiável**. Cada tendência tem **número específico**. Cada padrão proativo aponta **oportunidade concreta**. **Sem code execution, sem artefatos.** Aluno do plano gratuito termina a AP03 gastando exatamente 1 mensagem.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os arquivos de contexto carregados no Project Comercial Lumina:

1. **`plano-de-vendas-lumina.md`** — metas mensais, ICP por canal, ticket médio esperado, taxas de conversão saudáveis
2. **`estagios-do-pipeline-lumina.md`** — SLA por estágio, sinais de esfriamento, padrões de tendência
3. **`identidade-visual-lumina.md`** — tom da marca para alinhar os scripts de aproximação

Se o `plano-de-vendas-lumina.md` ou `estagios-do-pipeline-lumina.md` não estiverem disponíveis, alerte o usuário e pare.

Após carregar, escreva uma linha curta confirmando:

> ✅ Contexto comercial Lumina carregado. Gerando diagnóstico do pipeline.

---

## PASSO 1 — Identificar o pipeline alvo

Localize na conversa atual:

1. **Pipeline estruturado da semana atual** — gerado pela Skill `organizar-pipeline-lumina` (4 tabelas no chat acima)
2. **Snapshot da semana anterior** — disponível na Aba 2 do `pipeline-lumina-snapshot-segunda-[data].xlsx` carregado no Project
3. **Histórico de fechados (90 dias)** — disponível na Aba 3 da mesma planilha

Se o pipeline atual não estiver na conversa, **pare e oriente o usuário** a acionar primeiro a Skill `organizar-pipeline-lumina`.

Se o snapshot da semana anterior não estiver disponível, gere o diagnóstico apenas com o estado atual e alerte que as tendências (Bloco 3) ficarão restritas.

---

## PASSO 2 — Aplicar 5 regras de diagnóstico

### Regra 1 — Os 3 leads urgentes (Bloco 2)

Critérios de priorização (peso decrescente):

1. Valor estimado alto (R$ 15K+) E SLA estourado
2. Em Negociação ou Proposta com SLA estourado
3. Tempo parado acima de 10 dias
4. Repique de estágio (regrediu no funil)

Selecionar os **3 mais urgentes**. Para cada um, gerar:
- Identificação (ID + Nome + Canal + Vendedor + Estágio + Dias parado)
- Diagnóstico do gargalo (1-2 frases)
- **Script de aproximação em bloco de código** (60-80 palavras, tom Lumina wellness premium, pronto para WhatsApp/email)

### Regra 2 — Tendências por canal (Bloco 3)

Comparar pipeline atual vs semana anterior:
- **Canal acelerando:** aumento ≥ 15% no valor OU ≥ 20% no número de oportunidades
- **Canal desacelerando:** queda ≥ 10% no valor OU ≥ 15% no número de oportunidades

### Regra 3 — Estágio travado (Bloco 3)

Estágio com mais de 30% das oportunidades acima do SLA preocupante.

### Regra 4 — Oportunidade proativa (Bloco 4)

Procurar padrões não óbvios: cluster geográfico, cluster de perfil, cluster temporal, padrão de vendedor.

### Regra 5 — Humor do pipeline (Bloco 1)

- 🟢 **Saudável:** SLAs estourados ≤ 15% das oportunidades, conversão saudável, tendências positivas
- 🟡 **Atenção:** 15-25% de SLAs estourados, OU queda de pipeline acima de 10%, OU estágio travado claro
- 🔴 **Alerta:** ≥ 25% de SLAs estourados, OU queda acima de 20%, OU múltiplos estágios travados

---

## PASSO 3 — Renderizar 5 blocos NO CHAT (sem artefato)

**REGRA CRÍTICA:** NÃO gerar artefato `.md`. NÃO usar code execution. Apresentar tudo no chat com markdown enriquecido (blockquotes, tabelas, blocos de código para scripts copiáveis).

### Cabeçalho

```
# 📋 Diagnóstico Semanal do Pipeline — Lumina

**Semana de [data]** · Comparativo vs semana anterior: [data semana anterior]
```

### Bloco 1 — Humor do Pipeline

Formato:

```
## 🟡 Humor do Pipeline: ATENÇÃO

[Parágrafo único de 2-3 frases densas. Responde: estado geral em uma palavra, movimento mais relevante vs semana passada, sinal positivo OU sinal de alerta forte. Sempre com número específico.]
```

Cor do título varia conforme humor: 🟢 SAUDÁVEL / 🟡 ATENÇÃO / 🔴 ALERTA.

### Bloco 2 — 3 leads que precisam de atenção HOJE

Cada lead num mini-card visual usando blockquote + bloco de código para o script. Formato fixo:

```
## 🎯 3 leads que precisam de atenção HOJE

---

### 🔴 Lead 1 · [ID] · [Nome do cliente]

> **Canal:** [Canal] | **Vendedor:** [Vendedor] | **Estágio:** [Estágio] | **Valor:** **R$ [X]** | **Dias parado:** [N] dias

**Diagnóstico:** [1-2 frases sobre o que travou — usar contexto da observação na planilha + critérios objetivos]

**Script de aproximação (clique no botão Copiar):**

​```
[Script de 60-80 palavras em tom Lumina — sofisticado, contido, wellness premium, sem agressividade. Mencionar especificamente: tempo desde a última conversa, oferta concreta de retomada, tom acolhedor mas direto.]
​```

---

### 🔴 Lead 2 · [...]

[Mesmo formato]

---

### 🔴 Lead 3 · [...]

[Mesmo formato]
```

**IMPORTANTE:** o bloco de código (delimitado por três acentos graves) faz o Claude oferecer automaticamente botão "Copiar" no chat — é assim que o script vira copiável sem precisar de HTML.

### Bloco 3 — Tendências detectadas

3 sub-blocos em blockquotes coloridos por categoria:

```
## 📈 Tendências detectadas

### 🚀 Canal acelerando

> **[Canal X] +N% em valor (de R$ X para R$ Y)** vs semana passada.
>
> **Root cause provável:** [explicação em 1 frase]
>
> **→ Ação:** [ação concreta]

### 📉 Canal desacelerando

> **[Canal Y] -N% em volume (de N para M oportunidades)** vs semana passada.
>
> **Root cause provável:** [explicação em 1 frase]
>
> **→ Ação:** [ação concreta]

### 🚧 Estágio travado

> **[Estágio Z] tem N% das oportunidades acima do SLA preocupante** (M de N oportunidades).
>
> **Root cause provável:** [explicação em 1 frase]
>
> **→ Ação coletiva:** [ação concreta]
```

Se uma categoria não tiver achados materiais, escrever:

> *Sem tendências materiais nesta categoria esta semana.*

### Bloco 4 — Oportunidade da semana

```
## 💡 Oportunidade da semana

> **[Padrão identificado em 1 frase impactante]**
>
> [1 parágrafo de 2-3 frases explicando o padrão detectado, com números específicos.]
>
> **→ Ação sugerida:** [ação concreta]
```

Se não há padrão proativo material esta semana, escrever explicitamente:

> *Sem padrão proativo material esta semana. O pipeline está em movimento normal sem clusters detectáveis.*

### Bloco 5 — Ação recomendada da semana

```
## ✅ Ação recomendada da semana

> **Esta semana, foque em [X].**

**Cronograma sugerido:**

1. **Hoje (segunda):** [ação específica e curta]
2. **Até quarta:** [ação específica e curta]
3. **Antes de sexta:** [ação específica e curta]
```

### Mensagem de encerramento

```
---

✅ Diagnóstico completo. **Próximo passo:** acione a Skill `gerar-briefing-lumina` nesta mesma conversa para gerar o Briefing Visual do Pipeline (HTML autocontido para Carolina abrir toda segunda, ou versão em texto enriquecido se você está com créditos limitados no plano gratuito).
```

---

## Tom e estilo

- **Português brasileiro de finanças comerciais sênior** — direto, denso, sem floreios
- **Verbos no presente histórico** ("o canal acelera", "o estágio trava")
- **Citação de números sempre com magnitude:** "+R$ 22K (+12%)" preferível a "+22.000"
- **Tom alinhado à energia wellness premium da Lumina** nos scripts (sofisticado, contido, sem agressividade)
- **Sem qualificadores fracos** ("ligeiramente", "talvez") — se incerto, apresentar 2 hipóteses
- **Sem emojis na análise principal** — exceções: 🔴 🟡 🟢 (humor/SLA), 💡 (oportunidade), ✅ (ação), 🎯 📈 📉 🚀 🚧 (cabeçalhos de bloco)

---

## Tom dos scripts de aproximação (CRÍTICO)

Os 3 scripts são o produto principal da AP03. Eles precisam:

- **Soar Lumina** — wellness premium, sofisticado, contido, sem agressividade
- **Ser específicos** — mencionar tempo desde a última conversa, oferta concreta de retomada
- **Ser respeitosos** — sem pressão, sem "última chance", sem desconto fora de hora
- **Caber em 60-80 palavras** — para uso em WhatsApp e email
- **Terminar com pergunta aberta ou call to action gentil** — sem fechamento abrupto
- **Não usar jargão comercial pesado** ("fechar contrato", "bater meta") — usar linguagem natural

**Exemplo de tom correto** (não inventar para o aluno, gerar baseado no contexto real):

```
Olá [Nome], aqui é o [Vendedor] da Lumina. Há cerca de 2 semanas você me sinalizou interesse na linha pré-treino para a [academia/loja]. Imagino que a rotina deve estar puxada — queria saber se faz sentido retomarmos a conversa. Posso enviar uma versão atualizada da proposta com os valores do mês ou marcamos uma call rápida de 15 minutos. O que funciona melhor pra você?
```

---

## Não faça

- **NÃO gere artefato `.md`** — toda a saída é no chat
- **NÃO use code execution** — apenas markdown enriquecido
- **NÃO use Bloco 5 para genéricos** ("trabalhar duro") — sempre ação específica vinculada ao diagnóstico
- **NÃO inclua scripts genéricos** — cada um deve referenciar estágio, tempo parado, ou histórico da oportunidade
- **NÃO comente variações pequenas** (< 5% ou < R$ 5K) — material insignificante polui o diagnóstico
- **NÃO escreva diagnóstico genérico** ("foi uma semana desafiadora")
- **NÃO duplique conteúdo entre blocos** — o Humor do Pipeline NÃO repete os leads urgentes
- **NÃO invente padrões proativos sem fundamento** — se não há, dizer claramente

---

## Tratamento de erros

- **Pipeline organizado faltando na conversa:** pare e oriente a acionar `organizar-pipeline-lumina` antes
- **Snapshot semana anterior faltando:** gere só com estado atual e avise que tendências ficarão restritas
- **Histórico faltando:** gere normal mas avise que oportunidade proativa pode ficar menos rica
- **Pipeline vazio:** alerte e pergunte se planilha está correta
- **Todos com SLA estourado (situação extrema):** alerte que é situação de crise comercial e que threshold pode estar descalibrado

---

## Exemplo de comportamento esperado

**Input do usuário (na mesma conversa onde a Skill `organizar-pipeline-lumina` acabou de rodar):**
> "Agora gere o diagnóstico do pipeline desta semana."

**Output esperado (TUDO NO CHAT, SEM ARTEFATO):**

1. Linha de confirmação: "✅ Contexto comercial Lumina carregado. Gerando diagnóstico do pipeline."
2. Cabeçalho com data
3. **Bloco 1 — Humor do Pipeline** (parágrafo único, denso)
4. **Bloco 2 — 3 leads urgentes** (cada um com diagnóstico + script em bloco de código copiável)
5. **Bloco 3 — Tendências** (3 sub-blocos em blockquotes)
6. **Bloco 4 — Oportunidade da semana** (1 blockquote destacado)
7. **Bloco 5 — Ação recomendada** (blockquote + 3 bullets cronológicos)
8. Mensagem de encerramento direcionando para a Skill `gerar-briefing-lumina`

**O aluno gasta exatamente 1 mensagem.**
