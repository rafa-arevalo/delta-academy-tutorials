---
name: gerar-dre-lumina
description: Recebe uma planilha de lançamentos da Lumina já classificados no plano de contas e gera o DRE (Demonstração do Resultado do Exercício) consolidado do mês em formato tabular padrão CPC, com 3 margens calculadas e comparativo lado a lado com o mês anterior. Use sempre que o usuário enviar uma planilha estruturada de lançamentos da Lumina (output da Skill organizar-lancamentos-lumina) e pedir para gerar o DRE, fechar o mês, consolidar resultados ou produzir demonstrativo financeiro.
---

# gerar-dre-lumina

Skill que pega uma planilha de lançamentos já classificados conforme o plano de contas da Lumina e produz o DRE consolidado do mês em formato tabular executivo padrão.

**Filosofia:** rigor estrutural absoluto. A skill NUNCA inventa linhas do DRE — segue estritamente a estrutura padrão CPC (Comitê de Pronunciamentos Contábeis) e o plano de contas da Lumina carregado no Project. Output sempre tabular, sempre com comparativo vs mês anterior, sempre com as 3 margens calculadas.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os arquivos de contexto carregados no Project Financeiro Lumina:

1. **`plano-de-contas-lumina.md`** — para confirmar a estrutura de contas que vai ser somada
2. **`historico-financeiro-lumina.xlsx`** — Aba 1 contém o DRE de meses anteriores que será usado como comparativo
3. **`dre-lumina-setembro-2025.md`** (se carregado) — versão narrativa detalhada do DRE de setembro/2025 que pode trazer contexto adicional

Se o `plano-de-contas-lumina.md` não estiver disponível, **pare e avise o usuário** — sem o plano de contas não há como agrupar os lançamentos no DRE.

Após carregar, escreva uma linha curta confirmando:

> ✅ Plano de contas + histórico Lumina carregados. Pronto para gerar DRE.

---

## PASSO 1 — Receber e validar a planilha estruturada

O usuário vai anexar uma planilha `.xlsx` (geralmente o output da Skill `organizar-lancamentos-lumina`). Estrutura esperada:

- `Data` — data do lançamento
- `Descrição` — descrição
- `Valor (R$)` — valor monetário
- `Tipo` — Entrada / Saída
- `Forma de Pagamento`
- `Centro de Custo` — preenchido pela Skill anterior
- `Conta do Plano` — preenchido pela Skill anterior (esta é a coluna-chave que vai ser usada para agrupar)
- `Justificativa` — observações para casos ambíguos

**Validações antes de prosseguir:**

1. **Coluna "Conta do Plano" preenchida em todas as linhas** — se houver linhas vazias, listar quais e pedir para o usuário voltar à Skill `organizar-lancamentos-lumina`
2. **Período coerente em um único mês** — se a planilha tiver lançamentos de múltiplos meses, perguntar ao usuário qual mês deve ser consolidado
3. **Total de linhas e somatório bruto** — confirmar com o usuário antes de prosseguir (ex: *"Detectei 60 lançamentos referentes a outubro/2025, totalizando R$ X em entradas e R$ Y em saídas. Posso prosseguir com a geração do DRE?"*)

Se houver problemas, pare e peça ajuste antes de prosseguir.

---

## PASSO 2 — Agrupar lançamentos no DRE padrão CPC

Para cada linha do DRE, somar os lançamentos cuja `Conta do Plano` corresponda à categoria correta. Estrutura **obrigatória** do DRE (em ordem):

```
RECEITA BRUTA
   · Vendas E-commerce (por produto: Pré-treino, Creatina, Whey)
   · Vendas Loja SP
   · Vendas Loja RJ

(-) DEDUÇÕES
   · Impostos sobre vendas (Simples Nacional / Lucro Presumido)
   · Devoluções
   · Descontos comerciais

= RECEITA LÍQUIDA

(-) CPV — CUSTO DOS PRODUTOS VENDIDOS
   · Matéria-prima
   · Embalagens
   · Terceirização da produção

= LUCRO BRUTO

(-) DESPESAS OPERACIONAIS
   · Folha de pagamento + encargos
   · Aluguel (matriz + lojas)
   · Marketing — mídia paga
   · Marketing — influenciadores
   · Logística e fulfillment e-commerce
   · Software e plataformas
   · Contabilidade
   · Despesas administrativas

= RESULTADO OPERACIONAL (EBITDA)

(-) DESPESAS FINANCEIRAS
   · Antecipação de recebíveis
   · Taxa gateway de pagamento
   · Tarifas bancárias + IOF

= RESULTADO LÍQUIDO
```

**Regras de cálculo:**

- **Receita Bruta** = soma de todas as Entradas classificadas como Receita
- **Receita Líquida** = Receita Bruta − Deduções
- **Lucro Bruto** = Receita Líquida − CPV
- **Resultado Operacional (EBITDA)** = Lucro Bruto − Despesas Operacionais
- **Resultado Líquido** = Resultado Operacional − Despesas Financeiras

**Calcular as 3 margens:**

- **Margem Bruta** = Lucro Bruto / Receita Líquida
- **Margem Operacional** = Resultado Operacional / Receita Líquida
- **Margem Líquida** = Resultado Líquido / Receita Líquida

---

## PASSO 3 — Buscar o DRE do mês anterior para comparativo

Acessar a Aba 1 do `historico-financeiro-lumina.xlsx` carregado no Project. Buscar a coluna correspondente ao **mês imediatamente anterior** ao mês da planilha sendo processada.

**Exemplo:** se a planilha é de outubro/2025, buscar a coluna de setembro/2025.

Se houver o `dre-lumina-setembro-2025.md` carregado no Project, usar ele como fonte preferencial para setembro/2025 (mais detalhado que o `.xlsx`).

Se o mês anterior não estiver disponível no histórico, gerar o DRE só com o mês atual, **sem comparativo**, e avisar:

> ⚠️ Mês anterior não localizado no histórico. DRE gerado sem comparativo.

---

## PASSO 4 — Devolver o output em 2 formatos

### Formato 1 — Resumo no chat (tabela markdown)

Mostrar no chat **3 elementos**:

**1. DRE Consolidado · [Mês]/[Ano]** — tabela completa com colunas:

| Linha do DRE | [Mês Atual] | % sobre Rec. Líquida |
|---|---:|---:|

**2. Comparativo lado a lado vs mês anterior** — tabela:

| Linha do DRE | [Mês Anterior] | [Mês Atual] | Variação (R$) | Variação (%) |
|---|---:|---:|---:|---:|

Linhas obrigatórias do comparativo (não precisa todas as sub-linhas, só as agregadas):

- Receita Bruta
- Receita Líquida
- Lucro Bruto
- Resultado Operacional
- Resultado Líquido
- Margem Bruta (em p.p. — pontos percentuais)
- Margem Operacional (em p.p.)
- Margem Líquida (em p.p.)

**3. Destaque das 3 margens** — bloco final:

```
Margem Bruta: X,X%
Margem Operacional: X,X%
Margem Líquida: X,X%
```

### Formato 2 — Artefato Markdown (.md)

Use **artefato Markdown** (não Excel) para gerar o documento `dre-lumina-[mes]-[ano].md` seguindo o **mesmo formato** do `dre-lumina-setembro-2025.md` carregado no Project. Inclui:

- DRE Consolidado em tabela markdown
- 3 margens em destaque
- Composição da Receita por canal
- Composição da Receita por produto
- Comparativo com mês anterior
- *(NÃO inclua "Eventos relevantes do mês" nem "Pontos de atenção" nem "Olhar prospectivo" — esses blocos serão adicionados pela Skill de análise no próximo passo do pipeline)*

Nome do artefato: `dre-lumina-[mes]-[ano].md` (ex: `dre-lumina-outubro-2025.md`).

---

## Tom e estilo

- Português brasileiro executivo, direto, profissional
- **Formato tabular sempre** — DRE é estrutura tabular por natureza, não usar prosa para apresentar números
- Valores monetários no padrão brasileiro: `R$ 1.010.500,00` ou `R$ 1.010.500` (sem centavos para totais agregados)
- Percentuais sempre com 1 casa decimal: `60,0%`
- Pontos percentuais (variação de margens) com sufixo `p.p.`: `+2,4 p.p.`
- Tom alinhado à energia wellness premium da Lumina (sofisticado, contido, sem floreios)

---

## Não faça

- Não inventar linhas do DRE que não existam no plano de contas oficial
- Não pular linhas do DRE (mesmo que zeradas — manter a estrutura completa)
- Não fazer análise narrativa nem interpretação dos números (isso é trabalho da Skill `analisar-dre-lumina` no próximo passo)
- Não adicionar comentários ou observações livres no DRE — só os números
- Não arredondar valores além do padrão definido (manter R$ inteiros para totais e 1 casa decimal para %)
- Não alterar a ordem das linhas do DRE — sempre na ordem padrão CPC

---

## Tratamento de erros

- **Plano de contas faltando:** pare e peça ao usuário para carregar o `plano-de-contas-lumina.md` no Project antes de prosseguir
- **Histórico financeiro faltando:** gere o DRE só com o mês atual, sem comparativo, e avise
- **Planilha sem coluna "Conta do Plano":** pare e oriente o usuário a passar a planilha pela Skill `organizar-lancamentos-lumina` antes
- **Múltiplos meses na mesma planilha:** pergunte ao usuário qual mês consolidar
- **Lançamento com `Conta do Plano` que não existe no plano oficial:** liste essas linhas como exceção e pergunte ao usuário se deve ignorá-las ou reclassificar

---

## Exemplo de comportamento esperado

**Input do usuário:**
> "Anexei a planilha de lançamentos classificados de outubro/2025 da Lumina. Por favor gere o DRE."

**Output esperado:**

1. Linha de confirmação: "✅ Plano de contas + histórico Lumina carregados. Pronto para gerar DRE."
2. Validação do mês: "Detectei 60 lançamentos referentes a outubro/2025, totalizando R$ X em entradas e R$ Y em saídas. Vou prosseguir com a geração do DRE."
3. Resumo no chat com:
   - DRE Consolidado de outubro/2025 em tabela
   - Comparativo lado a lado vs setembro/2025
   - Destaque das 3 margens
4. Artefato `dre-lumina-outubro-2025.md` para download
5. Mensagem final: *"DRE pronto. Você pode acionar agora a Skill `analisar-dre-lumina` na mesma conversa para gerar a análise narrativa executiva."*
