---
name: gerar-dre-lumina
description: Gera o DRE (Demonstração do Resultado do Exercício) estruturado da rede Lumina a partir de uma planilha bruta de lançamentos contábeis. Use quando o usuário anexar uma planilha de lançamentos da Lumina e pedir para gerar o DRE, fechar o mês, consolidar resultados, ou pedir análise financeira mensal da rede.
---

# Gerar DRE Lumina

## Visão geral

Esta Skill processa uma planilha bruta de lançamentos contábeis da rede varejista Lumina (90 filiais em todos os estados do Brasil) e devolve o DRE consolidado mensal no formato padrão da empresa, com indicadores de margem calculados automaticamente.

## Quando acionar

Acione esta Skill quando o usuário:

- Anexar uma planilha de lançamentos contábeis da Lumina (`.xlsx` ou `.csv`) e pedir para gerar o DRE
- Pedir para fechar o mês financeiro da Lumina
- Pedir consolidação de resultados financeiros da rede
- Pedir análise financeira mensal a partir de uma planilha de lançamentos
- Mencionar termos como "DRE Lumina", "fechamento mensal Lumina", "consolidar planilha financeira"

Não acione esta Skill para análise narrativa de DRE já estruturado (existe outra Skill para isso) nem para geração de painel visual (também tem Skill própria).

## Input esperado

Uma planilha em formato `.xlsx` ou `.csv` contendo lançamentos contábeis brutos com as seguintes colunas mínimas:

- **Data** — data do lançamento
- **Tipo de Lançamento** — Receita, Dedução, CMV, Despesa Operacional, Despesa Financeira
- **Categoria** — agrupamento principal (ex: Vendas Brutas, Impostos sobre Vendas, Folha, Marketing)
- **Subcategoria** — agrupamento secundário (ex: B2C Físico, ICMS, Salários e Encargos Lojas)
- **Filial / Centro de Custo** — onde o lançamento ocorreu
- **Descrição** — texto descritivo do lançamento
- **Valor (R$)** — valor monetário (positivo para receitas, negativo para despesas)

## Processamento

Ao receber a planilha, execute os seguintes passos:

### 1. Leia a planilha completa

Identifique todas as colunas e linhas válidas. Ignore linhas em branco, cabeçalhos auxiliares ou anotações.

### 2. Classifique cada lançamento

Use o `plano-de-contas-lumina.md` e o `politica-classificacao-receitas-despesas.md` carregados no Project Financeiro Lumina para classificar cada lançamento na linha correta do DRE.

Regras de classificação chave:

- **Receita Bruta** = soma de todos os lançamentos com Tipo = "Receita" (vendas físicas + vendas online + vendas B2B leve, se houver)
- **Deduções** = soma dos lançamentos com Tipo = "Dedução" (impostos sobre vendas, devoluções, descontos comerciais, cancelamentos)
- **CMV** = soma dos lançamentos com Tipo = "CMV", incluindo custo de marca própria, custo de revenda e provisões
- **Despesas Operacionais** = soma dos lançamentos com Tipo = "Despesa Operacional" (aluguel, folha, marketing, logística, administrativo)
- **Despesas Financeiras** = soma dos lançamentos com Tipo = "Despesa Financeira" (antecipação de recebíveis, IOF, juros, hedge, tarifas)

### 3. Calcule os indicadores intermediários e finais

- **Receita Líquida** = Receita Bruta − Deduções
- **Lucro Bruto** = Receita Líquida − CMV
- **Margem Bruta (%)** = Lucro Bruto ÷ Receita Líquida × 100
- **Resultado Operacional** = Lucro Bruto − Despesas Operacionais
- **Margem Operacional (%)** = Resultado Operacional ÷ Receita Líquida × 100
- **Resultado Líquido** = Resultado Operacional − Despesas Financeiras
- **Margem Líquida (%)** = Resultado Líquido ÷ Receita Líquida × 100

### 4. Apresente o DRE no formato padrão da Lumina

Estruture o output como tabela markdown com 3 colunas: **Linha do DRE | Valor (R$) | % Receita Líquida**.

## Formato do output

O output deve seguir exatamente esta estrutura tabular:

```
DRE — Lumina · [Mês]/[Ano]

| Linha | Valor (R$) | % Receita Líquida |
|---|---|---|
| (+) Receita Bruta | XXX.XXX.XXX | — |
| (–) Deduções | (XX.XXX.XXX) | — |
| (=) Receita Líquida | XX.XXX.XXX | 100,0% |
| (–) CMV | (XX.XXX.XXX) | (XX,X%) |
| (=) Lucro Bruto | XX.XXX.XXX | XX,X% |
| (–) Despesas Operacionais | (XX.XXX.XXX) | (XX,X%) |
| (=) Resultado Operacional | XX.XXX.XXX | XX,X% |
| (–) Despesas Financeiras | (XX.XXX.XXX) | (XX,X%) |
| (=) Resultado Líquido | XX.XXX.XXX | XX,X% |
```

Após a tabela, inclua um bloco de **observações sobre a consolidação**:

- Total de lançamentos processados
- Período coberto pela planilha (data inicial e final dos lançamentos)
- Eventuais lançamentos descartados ou não classificados (com motivo)
- Quaisquer alertas relevantes (ex: linhas com valores em branco, categorias inesperadas)

## Regras de formatação

- Valores monetários sempre no formato brasileiro: ponto como separador de milhar, vírgula como separador decimal (ex: R$ 85.010.000,00)
- Valores negativos entre parênteses: `(25.490.000)` — não use sinal de menos
- Percentuais com uma casa decimal e vírgula: `43,8%`
- Linhas de subtotal (Receita Líquida, Lucro Bruto, Resultado Operacional, Resultado Líquido) destacadas em **negrito** na tabela
- Margem da Receita Líquida sempre é 100,0% (referência para os demais percentuais)

## Tom e estilo

- Direto e executivo — esta Skill produz output para CFO e analistas financeiros sêniores, não para iniciantes
- Sem explicações redundantes sobre o que é DRE — assume conhecimento do usuário
- Sem emojis ou floreios decorativos
- Estrutura tabular limpa, fiel à identidade visual minimalista oriental da Lumina

## Exemplo de output

Para uma planilha de outubro/2025 da Lumina, o output esperado é:

```
DRE — Lumina · Outubro/2025

| Linha | Valor (R$) | % Receita Líquida |
|---|---|---|
| (+) Receita Bruta | 110.500.000 | — |
| (–) Deduções | (25.490.000) | — |
| (=) **Receita Líquida** | **85.010.000** | **100,0%** |
| (–) CMV | (47.750.000) | (56,2%) |
| (=) **Lucro Bruto** | **37.260.000** | **43,8%** |
| (–) Despesas Operacionais | (27.610.000) | (32,5%) |
| (=) **Resultado Operacional** | **9.650.000** | **11,4%** |
| (–) Despesas Financeiras | (1.170.000) | (1,4%) |
| (=) **Resultado Líquido** | **8.480.000** | **10,0%** |

Observações sobre a consolidação:
- 70 lançamentos processados
- Período: 04/10/2025 a 31/10/2025
- Todos os lançamentos foram classificados corretamente
- Sem alertas relevantes
```

## Tratamento de erros

- **Se a planilha não tiver as colunas esperadas:** informe ao usuário quais colunas estão faltando e peça para anexar uma planilha completa.
- **Se houver lançamentos sem Tipo definido:** liste-os ao final do DRE como "Lançamentos não classificados" e prossiga com o que for possível classificar.
- **Se a Receita Líquida for zero ou negativa:** retorne o DRE normalmente mas adicione um alerta destacado de que os indicadores percentuais não são significativos para este período.

## Não faça

- Não invente lançamentos que não estão na planilha
- Não some valores de outras moedas (a planilha é sempre em R$)
- Não inclua análise narrativa do DRE — esse trabalho é de outra Skill ("Analisar DRE Lumina")
- Não gere o painel visual — esse trabalho é de outra Skill ("Gerar Painel Financeiro Lumina")
- Não modifique a estrutura tabular padrão sem solicitação explícita do usuário
