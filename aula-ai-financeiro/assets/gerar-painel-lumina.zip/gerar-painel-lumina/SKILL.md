---
name: gerar-painel-lumina
description: Gera o Painel Financeiro mensal da rede Lumina como artefato HTML autocontido, dentro da identidade visual minimalista oriental da marca, combinando DRE estruturado, análise narrativa e comparativos visuais num único arquivo pronto para download e compartilhamento. Use quando o usuário tiver o DRE e a análise narrativa do mês prontos e pedir para gerar o painel, dashboard, relatório visual, ou peça final para apresentar à liderança da Lumina.
---

# Gerar Painel Financeiro Lumina

## Visão geral

Esta Skill produz o **Painel Financeiro mensal da Lumina** como artefato HTML autocontido — uma peça visual única que combina, dentro da identidade visual minimalista oriental da marca:

- Capa institucional com nome da rede e período de referência
- Tabela completa do DRE consolidado
- Três cards de margens principais com semáforo visual
- Bloco de análise narrativa em destaque (Executive Summary)
- Comparativo visual com mês anterior

O output é um arquivo `.html` autocontido — sem dependências externas além de Google Fonts via CDN — pronto para baixar, abrir em qualquer navegador, salvar como PDF e compartilhar por e-mail, Slack ou WhatsApp.

## Quando acionar

Acione esta Skill quando o usuário:

- Tiver gerado o DRE com a Skill "gerar-dre-lumina" e a análise narrativa com a Skill "analisar-dre-lumina" e pedir para criar o painel/dashboard/peça visual final
- Pedir o painel financeiro da Lumina, dashboard mensal, peça executiva ou relatório visual
- Mencionar termos como "painel Lumina", "dashboard mensal", "relatório visual", "peça pra liderança", "PDF do mês"

Não acione esta Skill se ainda não houver DRE estruturado e análise narrativa disponíveis na conversa — neste caso oriente o usuário a primeiro gerar esses dois insumos com as Skills correspondentes.

## Input esperado

Três insumos devem estar disponíveis na conversa:

1. **DRE estruturado do mês atual** — gerado pela Skill "gerar-dre-lumina" e visível no histórico da conversa
2. **Análise narrativa do mês atual** — gerada pela Skill "analisar-dre-lumina" e visível no histórico
3. **Identidade visual da Lumina** — arquivo `identidade-visual-lumina.md` carregado no Project Financeiro Lumina (consultar para extrair paleta exata, tipografia e princípios de design)

Adicionalmente, deve haver no Project o arquivo de DRE de referência do mês anterior (ex: `dre-lumina-setembro-2025.md`), que contém os números usados no comparativo visual.

## Identidade visual a aplicar

A identidade Lumina é **minimalista oriental** — princípios de wabi-sabi, kintsugi, espaço negativo generoso, elegância contida. Aplicar rigorosamente os seguintes parâmetros no HTML gerado:

### Paleta de cores
```
--cor-papel-arroz:    #FAF7F2   (fundo principal)
--cor-sumi:           #2D3640   (texto principal e títulos)
--cor-champagne:      #C9A961   (destaques, números-chave, divisores, semáforo neutro)
--cor-pedra:          #8A8479   (texto secundário, legendas)
--cor-saudavel:       #5C6F5A   (verde sutil oliva, semáforo positivo)
--cor-atencao:        #C9A961   (champagne, semáforo de alerta moderado)
--cor-alerta:         #A85A4A   (terracota suave, semáforo crítico)
```

### Tipografia
- **Títulos:** Cormorant Garamond (peso 500/600, serifada elegante)
- **Corpo:** Inter (peso 400/500, sans-serif clean)
- Carregar via Google Fonts CDN: `https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Inter:wght@400;500;600&display=swap`

### Princípios visuais
- Espaço negativo generoso — nunca preencher mais de 60% da página
- Linhas finas (1px) em dourado champagne para divisores
- Sem sombras, sem gradientes, sem bordas grossas
- Dados como protagonistas — números maiores que labels
- Alinhamento generoso (margens internas de 60-80px)
- Símbolo de marca: pequeno círculo dourado vazado (15px) em pontos discretos
- Tabelas sem grade visível — apenas linhas finas horizontais entre seções

## Estrutura obrigatória do Painel HTML

O HTML deve conter exatamente os 5 blocos abaixo, na ordem:

### Bloco 1 — Capa institucional

- Centralizada vertical e horizontalmente em uma página A4 portrait
- Pequena linha horizontal dourada decorativa (60px) acima do título
- Título: "**LUMINA**" em Cormorant Garamond, peso 600, tamanho grande (~80pt)
- Subtítulo: "Painel Financeiro · [Mês] / [Ano]" em Inter, peso 400, em cor pedra
- Linha horizontal dourada decorativa abaixo do subtítulo
- Pequeno bloco discreto na base com data de geração e nota *"Documento confidencial — uso interno da diretoria"*
- Símbolo Lumina (círculo dourado vazado, 30px) centralizado no rodapé

### Bloco 2 — Tabela do DRE consolidado

- Título da seção: "Demonstração do Resultado · [Mês] / [Ano]"
- Tabela com 3 colunas: **Linha do DRE | Valor (R$) | % Receita Líquida**
- Linhas:
  - (+) Receita Bruta
  - (–) Deduções
  - (=) **Receita Líquida** (em negrito, com linha fina dourada acima)
  - (–) CMV
  - (=) **Lucro Bruto** (em negrito, com linha fina dourada acima)
  - (–) Despesas Operacionais
  - (=) **Resultado Operacional** (em negrito, com linha fina dourada acima)
  - (–) Despesas Financeiras
  - (=) **Resultado Líquido** (em negrito, com linha fina dourada acima e abaixo)
- Sem grades verticais — apenas linhas finas horizontais separando subtotais
- Valores monetários no formato brasileiro: `R$ 110.500.000`
- Valores negativos entre parênteses: `(25.490.000)`
- Percentuais com vírgula e uma casa decimal: `43,8%`

### Bloco 3 — Cards das 3 margens com semáforo visual

- Três cards horizontais lado a lado, mesmo tamanho
- Cada card com:
  - Pequeno círculo de semáforo no canto superior direito (cor verde-oliva/champagne/terracota conforme diagnóstico)
  - Label do indicador em Inter peso 500, em cor pedra: "MARGEM BRUTA" / "MARGEM OPERACIONAL" / "MARGEM LÍQUIDA"
  - Valor atual em destaque dominante: percentual em Cormorant Garamond, peso 600, tamanho grande (~48pt)
  - Linha fina dourada horizontal abaixo do valor (40px)
  - Pequeno texto comparativo: "vs. mês anterior · ±X,Xpp"
  - Diagnóstico em uma palavra abaixo (Saudável / Atenção / Alerta) em cor correspondente ao semáforo
- Faixas-alvo de referência (extrair do arquivo `identidade-visual-lumina.md` ou usar default):
  - Margem Bruta: 43%–46%
  - Margem Operacional: 11%–14%
  - Margem Líquida: 10%–13%

### Bloco 4 — Análise Narrativa em destaque

- Título da seção: "Análise do Mês"
- Subtítulo discreto: "Executive Summary"
- Três blocos de texto curtos lado a lado (mesma largura, 33% cada):
  - **Como fomos** — frase única em Cormorant Garamond, tamanho médio
  - **O que se preocupar** — frase única em Cormorant Garamond, tamanho médio
  - **O que fazer** — frase única em Cormorant Garamond, tamanho médio
- Cada bloco com pequena linha horizontal dourada acima
- Após o Executive Summary, abaixo, em corpo menor (Inter regular):
  - Seção "**Análise das margens**" — 3 parágrafos curtos, um por margem, com root cause e recomendação extraídos da análise narrativa gerada
  - Seção "**Movimentos materiais**" — bullets com variações relevantes
  - Seção "**Pontos de atenção**" — bullets com itens para investigação

### Bloco 5 — Comparativo visual com mês anterior

- Título da seção: "Comparativo · [Mês atual] vs. [Mês anterior]"
- Tabela de duas colunas com os 4 indicadores principais:
  - Receita Líquida
  - Lucro Bruto + Margem Bruta
  - Resultado Operacional + Margem Operacional
  - Resultado Líquido + Margem Líquida
- Para cada linha, mostrar: valor mês atual · valor mês anterior · variação (R$) · variação (%)
- Variações com seta sutil para cima (▲) ou para baixo (▼) em dourado champagne
- Linhas finas horizontais entre cada item

### Rodapé do painel

- Linha horizontal dourada fina cruzando a página
- Pequeno texto em cor pedra, alinhado à esquerda: "Painel gerado automaticamente · Lumina · Diretoria Financeira"
- Símbolo Lumina (círculo dourado vazado, 15px) à direita
- Data de geração no canto inferior direito

## Estrutura técnica obrigatória do HTML

O HTML deve ser **autocontido** seguindo rigorosamente:

### Configurações de página

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel Financeiro Lumina · [Mês]/[Ano]</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    /* Todo o CSS inline aqui */
  </style>
</head>
<body>
  <!-- Todo o conteúdo aqui -->
</body>
</html>
```

### Requisitos técnicos

- **Single file:** todo CSS no `<style>` no `<head>`, sem arquivos externos exceto Google Fonts
- **Sem JavaScript:** o painel é puramente estrutural e visual
- **Print-friendly:** usar `@media print` para ajustes de impressão (margens, quebras de página entre blocos)
- **Mobile responsivo:** breakpoint em 768px que reorganiza cards de margem em coluna única e blocos do Executive Summary em vertical
- **Página A4 portrait:** dimensões de impressão definidas com `@page { size: A4 portrait; margin: 15mm; }`
- **Page-breaks controlados:** cada bloco principal tem `page-break-before: always` no print para evitar cortes ruins

### Validações de qualidade

Antes de devolver o output, verifique:

- ✓ Todas as cores estão dentro da paleta Lumina especificada (não há roxos, azuis, verdes-vivos, etc.)
- ✓ Tipografia rigorosamente respeitada (Cormorant para títulos, Inter para corpo)
- ✓ Espaço negativo generoso (não há "blocos lotados")
- ✓ Linhas finas douradas como elementos decorativos (não bordas grossas)
- ✓ Valores monetários em formato brasileiro (R$ 110.500.000, percentuais com vírgula)
- ✓ Variações em pp (pontos percentuais) escritas corretamente: "+1,2pp", "-0,8pp"
- ✓ Sem emojis decorativos no HTML — apenas símbolos tipográficos discretos (▲▼○) quando especificado
- ✓ Símbolo Lumina (círculo dourado vazado) presente em pontos discretos

## Tom e estilo do conteúdo

- Linguagem executiva, alinhada à identidade contida da Lumina
- Frases enxutas, sem floreios
- Português brasileiro executivo
- Termos técnicos em inglês aceitáveis quando padrão de mercado (Executive Summary, root cause)

## Formato do output

O Claude deve devolver:

1. **Breve introdução conversacional** (2-3 frases) explicando que o painel foi gerado com sucesso
2. **Artefato HTML** completo, no painel lateral do Claude, com nome `painel-financeiro-lumina-[mes]-[ano].html`
3. **Breve mensagem de validação** após o artefato com:
   - Confirmação dos blocos gerados
   - Instruções de como baixar (clicar em "Download" no artefato)
   - Sugestão de próximos passos: abrir no navegador para validar visualmente, salvar como PDF se quiser compartilhar por e-mail

## Tratamento de erros

- **Se faltar o DRE atual ou a análise narrativa na conversa:** peça ao usuário para gerar com as Skills correspondentes antes de prosseguir
- **Se faltar o DRE de referência do mês anterior no Project:** peça para o usuário carregá-lo na seção Arquivos do Project antes de gerar o painel
- **Se a paleta visual não estiver disponível no Project:** use as cores default da especificação acima e alerte o usuário que o `identidade-visual-lumina.md` deveria estar carregado
- **Se algum dado parecer inconsistente entre DRE e análise narrativa:** alerte o usuário antes de gerar o painel para evitar peça final com erro

## Não faça

- Não invente números — extraia exclusivamente do DRE estruturado e da análise narrativa fornecidos
- Não use cores fora da paleta Lumina — nada de azul corporativo, verde-bandeira, vermelho-sangue
- Não use ícones de bibliotecas externas (Font Awesome, Material Icons) — apenas símbolos tipográficos
- Não inclua imagens externas (logos, fotos, gráficos de bibliotecas) — tudo é HTML/CSS puro
- Não dependa de JavaScript — o painel deve renderizar identicamente sem JS habilitado
- Não use frameworks (Bootstrap, Tailwind) — CSS vanilla puro inline
- Não preencha o painel com elementos decorativos desnecessários — minimalismo é obrigatório
- Não use grades visíveis em tabelas — apenas linhas finas horizontais entre seções
- Não inclua dashboards interativos, gráficos animados, ou widgets dinâmicos — o painel é estático

## Exemplo de comportamento esperado

Quando acionada com DRE de outubro/2025 e análise narrativa correspondente disponíveis na conversa:

> Gerei o **Painel Financeiro Lumina · Outubro/2025** aplicando a identidade visual da marca. O artefato HTML está disponível para download no painel lateral.
>
> **Estrutura do painel:**
> - Capa institucional com período de referência
> - DRE consolidado completo
> - 3 cards de margens (Bruta 43,8% atenção · Operacional 11,4% saudável · Líquida 10,0% atenção)
> - Análise narrativa em destaque com Executive Summary
> - Comparativo visual outubro vs. setembro
>
> **Próximos passos:**
> 1. Clique em "Download" no artefato para salvar `painel-financeiro-lumina-outubro-2025.html`
> 2. Abra o arquivo no navegador para validar visualmente
> 3. Para compartilhar por e-mail, use Cmd+P (Mac) ou Ctrl+P (Windows) e salve como PDF
>
> [artefato HTML autocontido]
