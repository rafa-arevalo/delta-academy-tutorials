---
name: gerar-painel-lumina
description: Lê o DRE e a análise narrativa da Lumina gerados na mesma conversa pelas Skills gerar-dre-lumina e analisar-dre-lumina e produz um Painel Financeiro Mensal em HTML autocontido — peça visual única em formato editorial wellness premium, pronta para apresentar à liderança ou conselho. Use sempre que o usuário tiver gerado DRE + análise e pedir para criar o painel, gerar a peça visual, montar o relatório executivo, fechar o material do mês ou compilar o painel financeiro.
---

# gerar-painel-lumina

Skill que traduz o conteúdo financeiro estruturado e analisado (DRE + análise narrativa) em uma peça visual única — arquivo HTML autocontido que respeita rigorosamente a identidade visual minimalismo wellness premium da Lumina.

**Filosofia:** o painel é a **tradução final** do trabalho cognitivo das APs anteriores. Não inventa conteúdo novo — apenas organiza e renderiza o que já existe nos artefatos da conversa, em formato de comunicação executiva. **Editável, autocontido, print-friendly, mobile-responsive.**

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os arquivos de contexto carregados no Project Financeiro Lumina:

1. **`identidade-visual-lumina.md`** — paleta de cores, tipografia, princípios de design
2. **`historico-financeiro-lumina.xlsx`** — Aba 2 (KPIs Operacionais) e Aba 3 (Eventos Relevantes) — para enriquecer o painel se relevante
3. **`dre-lumina-setembro-2025.md`** (se carregado) — referência estrutural

Se o `identidade-visual-lumina.md` não estiver disponível, **pare e avise o usuário** — sem a identidade visual carregada, o painel sairia genérico, sem o DNA da marca.

Após carregar, escreva uma linha curta confirmando:

> ✅ Identidade visual + histórico Lumina carregados. Pronto para gerar painel.

---

## PASSO 1 — Identificar DRE e Análise narrativa na conversa

Localize na conversa atual:

1. **DRE estruturado** — gerado pela Skill `gerar-dre-lumina` (tabela CPC + comparativo + 3 margens)
2. **Análise narrativa** — gerada pela Skill `analisar-dre-lumina` (5 blocos Executive Summary)

Se um dos dois estiver faltando, **pare e oriente o usuário**:

- Sem DRE → "Acione primeiro a Skill `gerar-dre-lumina` antes desta."
- Sem análise → "Acione primeiro a Skill `analisar-dre-lumina` antes desta."

Se ambos estiverem presentes mas forem de meses diferentes, use o **mais recente** e avise o usuário.

---

## PASSO 2 — Estruturar o painel em 5 blocos

O painel sempre tem **5 blocos na ordem fixa**:

### Bloco 1 — Cabeçalho institucional Lumina

- Logo SVG inline da Lumina (círculo verde-musgo vazado + tipografia Fraunces "lumina" em lowercase)
- Título: "Painel Financeiro Mensal"
- Subtítulo: nome do mês por extenso + ano (ex: "Outubro · 2025")
- Data de fechamento contábil
- Linha divisória sutil em verde-claro pálido

### Bloco 2 — Os 3 indicadores principais

Cards visuais grandes, em grid de 3 colunas (1 coluna em mobile), mostrando:

- **Receita Líquida** — valor monetário grande + % de variação vs mês anterior + seta indicando direção (▲ verde para alta, ▼ coral para queda)
- **Resultado Operacional (EBITDA)** — mesmo padrão
- **Resultado Líquido** — mesmo padrão

Cada card tem:
- Label da métrica em texto pequeno e tracking aberto, em cinza-taupe
- Valor monetário grande, em Fraunces, cor verde-musgo
- Variação vs mês anterior em texto pequeno, com seta colorida

### Bloco 3 — DRE consolidado

Tabela limpa em formato CPC. Estrutura de colunas:

- Linha do DRE
- Valor do mês atual (R$)
- % sobre Receita Líquida
- Variação vs mês anterior (R$ + %)

Princípios visuais:
- Sem grade visível (só linhas horizontais finas em verde-claro pálido entre seções)
- Linhas de subtotal (Receita Líquida, Lucro Bruto, Resultado Operacional, Resultado Líquido) em destaque tipográfico (negrito, cor verde-musgo)
- Linhas de detalhamento (sub-itens) em texto regular, cinza-taupe
- Variações negativas em coral terroso, positivas em verde-musgo (sutil, sem agressividade visual)
- Valores monetários alinhados à direita, no padrão brasileiro (`R$ 1.010.500`)
- Percentuais com 1 casa decimal alinhados à direita

### Bloco 4 — As 3 margens com semáforo visual

Grid de 3 cards (1 coluna em mobile):

- **Margem Bruta**
- **Margem Operacional**
- **Margem Líquida**

Cada card tem:
- Label da margem
- Valor percentual grande em Fraunces
- Comparativo vs mês anterior (em pontos percentuais)
- **Semáforo visual:**
  - 🟢 Verde-musgo: melhorou (variação ≥ +0,5 p.p.)
  - 🟡 Dourado champagne: estável (variação entre -0,5 e +0,5 p.p.)
  - 🟠 Coral terroso: piorou (variação ≤ -0,5 p.p.)

O indicador é discreto — uma faixa lateral colorida ou um pequeno ponto, não uma cor de fundo dominante. **A regra Lumina é minimalismo**, não sinalização agressiva.

### Bloco 5 — Análise narrativa

Renderizar os **5 blocos da análise narrativa** (output da Skill `analisar-dre-lumina`) em tipografia editorial:

- **Resumo Executivo** — parágrafo único, em destaque (fonte ligeiramente maior, line-height generoso, max-width estreito para legibilidade tipo revista)
- **Análise das 3 Margens** — três blocos curtos, cada um com título da margem e parágrafo de root cause
- **Movimentos Materiais** — lista numerada limpa, com nome da linha do DRE em destaque
- **Olhar Prospectivo** — 3-4 parágrafos curtos
- **Pontos de Atenção CFO** — lista numerada com badges de prioridade (Alta · Média · Baixa) em cores discretas

Princípio: **dados como protagonistas, prosa como suporte.** Tipografia Fraunces nos títulos dos blocos, Inter no corpo. Espaço negativo generoso entre seções.

---

## PASSO 3 — Renderizar como HTML autocontido

Gerar o painel como **artefato HTML único**, com as seguintes especificações técnicas:

### Estrutura HTML

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel Financeiro Lumina · [Mês]/[Ano]</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    /* CSS inline aqui — sem .css externo */
  </style>
</head>
<body>
  <!-- 5 blocos aqui -->
</body>
</html>
```

### Paleta de cores (CSS variables)

```css
:root {
  --bg: #FBF9F5;          /* Branco quente neutro */
  --musgo: #5C7A5A;       /* Verde-musgo (cor estrutural) */
  --coral: #C97A5A;       /* Coral terroso (acentos) */
  --taupe: #8A857D;       /* Cinza-taupe (texto secundário) */
  --verde-claro: #D4DDC9; /* Verde-claro pálido (linhas, fundos sutis) */
  --champagne: #D1AA53;   /* Dourado champagne (semáforo amarelo) */
  --texto: #2C2C2A;       /* Texto principal */
}
```

### Tipografia

- **Títulos:** `font-family: 'Fraunces', Georgia, serif;` — pesos 400/500/600
- **Corpo:** `font-family: 'Inter', system-ui, sans-serif;` — pesos 400/500
- **Tamanhos:** generosos no desktop, escalando para mobile via `clamp()` ou media queries

### Layout

- `max-width` central de ~840px no desktop
- Padding lateral generoso
- Seções separadas por espaço negativo (não por bordas)
- Mobile-first: layout em coluna única abaixo de 768px

### Print-friendly

`@media print` com:
- Margens A4 ajustadas
- Cores preservadas (`-webkit-print-color-adjust: exact;`)
- Quebras de página inteligentes (`page-break-inside: avoid` em cards e tabelas)
- Fontes em tamanho legível impressas

### Sem dependências externas

- ❌ Sem `<link>` para CSS externo (exceção: Google Fonts CDN, opcional)
- ❌ Sem JavaScript de servidor
- ❌ Sem imagens externas (logo é SVG inline)
- ✅ Tudo embarcado no único arquivo `.html`

### Logo SVG inline

Renderizar a logo da Lumina como SVG inline no Bloco 1, conforme descrição em `identidade-visual-lumina.md` — círculo verde-musgo vazado (apenas contorno fino) à esquerda + texto "lumina" em Fraunces lowercase à direita.

---

## PASSO 4 — Devolver o output

### No chat (curto)

Mensagem direta confirmando geração:

> ✅ **Painel Financeiro Lumina · [Mês]/[Ano] gerado.**
>
> Arquivo HTML autocontido pronto para download. Abra no navegador para visualizar — funciona em qualquer dispositivo, qualquer browser. Para imprimir ou exportar como PDF, use Ctrl+P (ou Cmd+P no Mac).

### Como artefato

Gerar artefato HTML com nome `painel-lumina-[mes]-[ano].html` (ex: `painel-lumina-outubro-2025.html`).

---

## Tom e estilo

- **Visual minimalismo wellness premium** — fresca, sofisticada, energética sem ser agressiva
- **Espaço negativo é protagonista** — nunca preencher mais de 60% da página
- **Dados acima de ornamentos** — números e gráficos são o foco, decoração é mínima
- **Linhas finas, nunca grossas** — 1px para divisores
- **Sem grade visível em tabelas** — só linhas horizontais finas entre seções
- **Hierarquia por espaçamento, não por cor** — variações de tamanho e peso tipográfico fazem o trabalho
- **Sem sombras pesadas, sem gradientes, sem ornamentos**

---

## Não faça

- Não inventar conteúdo que não esteja no DRE ou na análise narrativa — o painel é tradução visual, não criação de conteúdo novo
- Não usar JavaScript para carregar dados externamente — tudo deve estar embarcado no HTML
- Não usar CSS externo via `<link>` — exceção apenas para Google Fonts CDN (opcional)
- Não usar emojis exceto onde explicitamente previsto (semáforo das margens, ícones de variação)
- Não usar cores fora da paleta Lumina
- Não usar sombras pesadas, gradientes ou bordas grossas — fere o princípio de minimalismo
- Não usar grade visível nas tabelas
- Não usar fundos coloridos dominantes — fundo principal é sempre o branco quente `#FBF9F5`
- Não preencher a página inteira — espaço negativo é protagonista
- Não duplicar informações entre blocos — cada bloco tem uma responsabilidade visual clara

---

## Tratamento de erros

- **Identidade visual faltando no Project:** pare e oriente o usuário a carregar o `identidade-visual-lumina.md` no Project antes de prosseguir
- **DRE faltando na conversa:** pare e oriente o usuário a acionar a Skill `gerar-dre-lumina` antes
- **Análise narrativa faltando na conversa:** pare e oriente o usuário a acionar a Skill `analisar-dre-lumina` antes
- **DRE e análise de meses diferentes:** use o mais recente e avise o usuário

---

## Exemplo de comportamento esperado

**Input do usuário (na mesma conversa onde DRE e análise já foram gerados):**
> "Gere agora o painel financeiro de outubro/2025."

**Output esperado:**

1. Linha de confirmação: "✅ Identidade visual + histórico Lumina carregados. Pronto para gerar painel."
2. Mensagem curta: "✅ Painel Financeiro Lumina · Outubro/2025 gerado. Arquivo HTML autocontido pronto para download. Abra no navegador para visualizar — funciona em qualquer dispositivo, qualquer browser. Para imprimir ou exportar como PDF, use Ctrl+P (ou Cmd+P no Mac)."
3. Artefato `painel-lumina-outubro-2025.html` gerado com os 5 blocos completos
4. Mensagem final: *"Painel pronto. Você pode usar este arquivo como entregável final do mês — apresentar à liderança, enviar por email, salvar como PDF, ou subir num Drive compartilhado. A próxima etapa do pipeline (AP05) é configurar a tarefa agendada que dispara este fluxo automaticamente todo mês."*
