---
name: analisar-dre-lumina
description: Lê o DRE da Lumina gerado na mesma conversa pela Skill gerar-dre-lumina e produz uma análise narrativa executiva no padrão Executive Summary, estruturada em 5 blocos (resumo executivo, análise das 3 margens com root causes, movimentos materiais, olhar prospectivo, pontos de atenção CFO). Use sempre que o usuário tiver acabado de gerar um DRE com a Skill gerar-dre-lumina e pedir análise, comentário, narrativa, comparação detalhada com mês anterior, variance analysis, ou material para apresentar à liderança.
---

# analisar-dre-lumina

Skill que produz análise narrativa executiva profunda do DRE da Lumina, no padrão **Executive Summary** lido por CFO/liderança em 30 segundos. Lê o DRE gerado pela Skill `gerar-dre-lumina` na mesma conversa e enriquece com root causes, materialidade e olhar prospectivo.

**Filosofia:** análise materializada, não verbosa. Comenta apenas variações que **importam para a liderança** (R$ 100K em valor absoluto OU 5% em variação relativa). Cada movimento comentado tem **root cause identificado** — nunca afirma "X cresceu" sem explicar **por que** cresceu. Linguagem de finanças sênior, sem floreios.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os arquivos de contexto carregados no Project Financeiro Lumina:

1. **`historico-financeiro-lumina.xlsx`** — Aba 2 (KPIs Operacionais) e Aba 3 (Eventos Relevantes) — fontes de root causes e contexto
2. **`dre-lumina-setembro-2025.md`** (se carregado) — versão narrativa do DRE de setembro/2025 com eventos relevantes e drivers de variação
3. **`identidade-visual-lumina.md`** — para alinhar tom da análise à energia wellness premium da marca

Se o histórico não estiver disponível, alerte o usuário, mas continue (avisando que a análise será baseada apenas no DRE em tela).

Após carregar, escreva uma linha curta confirmando:

> ✅ Histórico Lumina carregado. Pronto para análise narrativa.

---

## PASSO 1 — Identificar o DRE alvo na conversa

Localize na conversa atual o DRE gerado pela Skill `gerar-dre-lumina`. Esse DRE deve ter:

- Tabela do DRE Consolidado do mês atual
- Tabela comparativa lado a lado vs mês anterior
- Bloco com as 3 margens

Se não houver DRE na conversa, **pare e peça ao usuário** para acionar primeiro a Skill `gerar-dre-lumina` antes desta.

Se houver múltiplos DREs na conversa (de meses diferentes), use o **mais recente**.

---

## PASSO 2 — Aplicar threshold de materialidade

**Regra de materialidade Lumina:**

> Comentar apenas variações que atendam **pelo menos UM** destes critérios:
>
> - **Valor absoluto ≥ R$ 100.000** (cem mil reais)
> - **Variação relativa ≥ 5%** (em qualquer direção, positiva ou negativa)
>
> Variações abaixo desse threshold são **ignoradas** na análise — são consideradas ruído operacional para uma empresa do porte da Lumina.

Aplique este threshold em cada linha do DRE comparativo (Receita Bruta, Receita Líquida, Lucro Bruto, Resultado Operacional, Resultado Líquido, e cada subgrupo de despesa).

**Exceção — margens:** variações em **margens** (Bruta, Operacional, Líquida) sempre são comentadas se houver variação ≥ 1 ponto percentual (positivo ou negativo), independente do threshold acima — porque margens são indicadores estruturais.

---

## PASSO 3 — Gerar análise em 5 blocos estruturados

Produzir a análise como **artefato Markdown** (`.md`), seguindo **rigorosamente** a estrutura abaixo:

### Bloco 1 — Resumo Executivo (3-4 frases)

Resumo executivo lido em **15 segundos**. Deve responder:

- Como foi o mês, em uma palavra (forte, fraco, em linha, transição)?
- Qual foi o movimento mais relevante? (1 frase)
- O resultado líquido foi acima ou abaixo do mês anterior, e em quanto?
- Há algum sinal de alerta ou destaque positivo extraordinário?

**Formato:** parágrafo único, denso, sem bullet points.

**Exemplo:**
> Outubro/2025 foi um mês forte para a Lumina, com receita líquida crescendo 12,8% vs setembro e resultado líquido subindo 18,2%. O destaque positivo foi a aceleração do canal e-commerce (+R$ 95K em receita) impulsionada pela campanha "Pré Black Friday Antecipada", que entregou ROI superior à média histórica. Pelo lado dos custos, houve aumento controlado nas despesas de mídia (+22%) — coerente com a estratégia da janela pré-Black Friday. Margem operacional sustentada em 21,2%, marginalmente acima de setembro.

---

### Bloco 2 — Análise das 3 margens (com root causes)

Para **cada uma das 3 margens** (Bruta, Operacional, Líquida):

**Estrutura por margem:**

```
**Margem [Nome]: X,X% (vs Y,Y% em [mês anterior]) → variação de ±Z,Z p.p.**

[1-2 frases explicando o movimento e o root cause]
```

**Exemplo:**

> **Margem Bruta: 59,2% (vs 60,0% em setembro) → variação de -0,8 p.p.**
>
> Leve compressão da margem bruta, dentro do esperado e ainda dentro da faixa saudável do setor (55-65%). O movimento decorre principalmente do aumento do CPV da matéria-prima do whey protein — fornecedor reajustou preços em outubro após estabilização do dólar. Ainda em monitoramento.

**Identificação de root causes:** consulte os eventos relevantes do mês (Aba 3 do `.xlsx`) e o DRE de setembro (`.md`) para identificar drivers reais. Se não houver evento explícito, mencione o driver matemático mais provável (mix de produtos, sazonalidade, etc.).

---

### Bloco 3 — Movimentos materiais (com threshold)

Lista de movimentos relevantes que passaram no threshold de materialidade.

**Formato:** lista numerada, cada item com 2-3 frases:

```
1. **[Linha do DRE]:** [variação em R$ e %] → [root cause]
2. **[Linha do DRE]:** [variação em R$ e %] → [root cause]
3. ...
```

**Exemplo:**

> 1. **Receita Bruta E-commerce:** +R$ 95.000 (+13,6%) → impacto da campanha "Pré Black Friday Antecipada" lançada em 24/out, com cupom de -10% em todo o portfólio.
> 2. **Marketing — Mídia paga:** +R$ 7.300 (+22,3%) → aumento programado de investimento na janela pré-Black Friday. Custo por aquisição (CAC) manteve-se estável em R$ 39 (vs R$ 38 em setembro).
> 3. **CPV Matéria-prima:** +R$ 18.400 (+8,0%) → reajuste do fornecedor de whey protein após estabilização cambial. Margem bruta absorveu o impacto sem deterioração estrutural.

Em geral, espere identificar entre **3 e 6 movimentos materiais** por mês. Se identificar mais de 8, é sinal que o threshold pode ter sido aplicado de forma muito frouxa — revise.

---

### Bloco 4 — Olhar prospectivo

Análise dos **vetores que influenciam o próximo mês**, baseada nos movimentos do mês atual + eventos relevantes conhecidos + sazonalidade do setor wellness.

**Formato:** texto estruturado em 3-4 parágrafos curtos. Identificar:

- **Ventos favoráveis** — fatores que devem impulsionar o próximo mês (sazonalidade, momentum atual, decisões já tomadas)
- **Ventos contrários** — riscos identificados que podem deteriorar o próximo mês (custos crescentes, riscos de canal, competição)
- **Decisões pendentes** — definições que estão em curso e podem mudar o cenário

**Exemplo:**

> **Ventos favoráveis para novembro:** mês concentra a Black Friday, principal evento promocional do varejo brasileiro — historicamente representa entre 25% e 35% da receita do mês para empresas de e-commerce wellness. A Lumina entra com momentum positivo do canal e-commerce e estoque renovado.
>
> **Ventos contrários:** o aumento de custo de mídia em outubro tende a se intensificar ainda mais em novembro — toda a categoria disputa inventário no Meta e Google. Margem operacional pode ficar pressionada na primeira metade do mês.
>
> **Decisão pendente:** finalização da negociação com novo fornecedor de creatina monohidratada, que pode reduzir CPV em ~3% se concretizada. Decisão deve ocorrer até a primeira semana de novembro.

---

### Bloco 5 — Pontos de atenção para o CFO

Lista direta de **3 a 5 pontos** que merecem decisão ou atenção da liderança financeira nos próximos 30 dias.

**Formato:** lista numerada, cada item com 1 frase + indicação de prioridade (Alta / Média / Baixa).

**Exemplo:**

> 1. **[Alta]** Aprovar (ou não) a finalização do contrato com novo fornecedor de creatina — janela fechando em 7 de novembro.
> 2. **[Alta]** Definir teto de investimento em mídia paga para a Black Friday (cenário-base sugere R$ 75K, cenário-agressivo R$ 110K).
> 3. **[Média]** Revisar política de antecipação de recebíveis — taxa atual de 1,8% pode ser renegociada com volume crescente.
> 4. **[Baixa]** Avaliar se faz sentido reajustar preço do whey protein para repor margem bruta — recomendação preliminar: aguardar dezembro.

---

## PASSO 4 — Devolver o output em 2 formatos

### Formato 1 — Resumo no chat

Apresentar **apenas o Bloco 1 (Resumo Executivo)** no chat — o restante vai no artefato. Isso permite que o usuário leia a "manchete" rápida no chat e abra o artefato para o aprofundamento.

Adicionar logo abaixo:

> A análise completa nos 5 blocos está disponível como artefato para download.

### Formato 2 — Artefato Markdown (.md)

Gerar artefato `analise-dre-lumina-[mes]-[ano].md` com **os 5 blocos completos**, na ordem:

1. Resumo Executivo
2. Análise das 3 Margens
3. Movimentos Materiais
4. Olhar Prospectivo
5. Pontos de Atenção para o CFO

Cabeçalho do artefato deve ter:

```markdown
# Análise DRE — Lumina · [Mês]/[Ano]

> Análise narrativa executiva produzida em [data] pela Skill `analisar-dre-lumina`.
> Lida em 3-5 minutos. Threshold de materialidade aplicado: R$ 100K em valor absoluto ou 5% em variação relativa.
```

---

## Tom e estilo

- **Português brasileiro de finanças sênior** — direto, denso, sem floreios. Tom que um CFO usaria com seu controller.
- **Verbos no presente histórico** quando descrevendo o mês ("a margem comprime", "o canal acelera") — não no passado nem no futuro.
- **Citação de números sempre com magnitude:** "+R$ 95K" ou "+R$ 95.000" são preferíveis a "+95.000". Para totais grandes, "R$ 1,1M" é aceitável.
- **Sem qualificadores fracos** ("ligeiramente", "talvez", "parece que") — se a análise é incerta, apresente as duas hipóteses; se é certa, afirme.
- **Sem emojis na análise** — exceção apenas para o ícone de prioridade nos Pontos de Atenção, se ajudar visualmente.
- Tom alinhado à energia wellness premium da Lumina (sofisticado, contido, profissional).

---

## Não faça

- Não use o bloco 5 (Pontos de Atenção) para parabenizar a empresa por bons resultados — pontos de atenção são **decisões pendentes**, não comemorações.
- Não inclua a análise como prosa corrida — a estrutura dos 5 blocos é **fixa e obrigatória**.
- Não invente eventos ou root causes que não tenham fundamento nos arquivos do Project ou na lógica matemática do DRE.
- Não comente variações abaixo do threshold — material insignificante polui a análise.
- Não escreva análise genérica ("foi um mês desafiador") — toda afirmação deve ter número e root cause.
- Não duplique conteúdo entre os blocos — o resumo executivo NÃO deve repetir os movimentos materiais; deve **sintetizá-los**.

---

## Tratamento de erros

- **Sem DRE na conversa:** pare e oriente o usuário a acionar primeiro a Skill `gerar-dre-lumina`.
- **DRE sem mês anterior para comparar:** análise reduzida — Bloco 2 (margens) e Bloco 3 (movimentos materiais) ficam restritos a comentário sobre o nível atual, sem variação. Bloco 4 (olhar prospectivo) e Bloco 5 (pontos de atenção) podem ser produzidos normalmente.
- **Histórico Lumina (xlsx + md) faltando:** gere a análise com base apenas no DRE em tela e na lógica matemática. Avise no início do output que a profundidade da análise está reduzida pela falta de contexto histórico.
- **Threshold descalibrado para o porte da empresa:** caso a análise produza menos de 2 movimentos materiais ou mais de 8, sinalize ao usuário que o threshold pode precisar ser revisto para esse mês específico.

---

## Exemplo de comportamento esperado

**Input do usuário (na mesma conversa onde a Skill `gerar-dre-lumina` acabou de rodar):**
> "Agora gere a análise narrativa do DRE de outubro/2025."

**Output esperado:**

1. Linha de confirmação: "✅ Histórico Lumina carregado. Pronto para análise narrativa."
2. Resumo Executivo (Bloco 1) apresentado no chat — 3-4 frases densas
3. Linha: "A análise completa nos 5 blocos está disponível como artefato para download."
4. Artefato `analise-dre-lumina-outubro-2025.md` gerado com os 5 blocos completos
5. Mensagem final: *"Análise pronta. Você pode usar este arquivo + o DRE estruturado como input para a Skill `gerar-painel-lumina` (AP04) que vai compilar tudo no painel HTML executivo."*
