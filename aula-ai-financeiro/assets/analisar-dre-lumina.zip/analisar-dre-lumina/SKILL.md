---
name: analisar-dre-lumina
description: Gera análise narrativa executiva do DRE da rede Lumina comparando o mês atual com o mês anterior, no formato de Executive Summary (CFO-ready) com root causes, recomendações acionáveis e olhar prospectivo. Use quando o usuário tiver gerado um DRE da Lumina com a Skill "gerar-dre-lumina" e pedir análise, comentário, comparação com mês anterior, variance analysis, ou narrativa para apresentar à liderança.
---

# Analisar DRE Lumina

## Visão geral

Esta Skill produz uma análise narrativa executiva do DRE mensal da rede Lumina (90 filiais em todos os estados do Brasil), comparando o mês atual com o mês anterior carregado como referência no Project Financeiro. O output segue padrões de FP&A executivo (Executive Summary primeiro, root causes em vez de descrições, recomendações acionáveis, materiality threshold explícito, olhar prospectivo).

## Quando acionar

Acione esta Skill quando o usuário:

- Tiver gerado um DRE com a Skill "gerar-dre-lumina" e pedir análise, comentário ou narrativa
- Pedir comparação do mês atual com o mês anterior
- Pedir variance analysis ou explicação de variações
- Pedir uma análise narrativa para apresentar à liderança/CFO
- Mencionar termos como "analisar DRE Lumina", "comentário do mês", "explicar variações", "narrativa do fechamento"

Não acione esta Skill se ainda não houver um DRE estruturado para analisar — neste caso oriente o usuário a primeiro gerar o DRE com a Skill "gerar-dre-lumina".

## Input esperado

Dois insumos são necessários para a análise:

1. **DRE do mês atual** — gerado pela Skill "gerar-dre-lumina" na mesma conversa, ou colado pelo usuário no chat
2. **DRE de referência do mês anterior** — disponível como arquivo carregado no Project Financeiro Lumina (ex: `dre-lumina-setembro-2025.md` para análise de outubro)

Se o DRE de referência não estiver disponível, peça ao usuário para carregá-lo no Project antes de prosseguir.

## Materiality threshold

Variações entre os dois meses são consideradas relevantes (e merecem explicação na análise) quando atendem **qualquer um** dos critérios:

- Variação absoluta acima de **R$ 1.000.000** em qualquer linha
- Variação percentual acima de **5%** vs. mês anterior em margens (Bruta, Operacional, Líquida)
- Mudança de classificação de saúde da margem (de saudável para atenção, ou de atenção para alerta)

Variações abaixo desses thresholds podem ser mencionadas brevemente, mas não devem ser explicadas em profundidade — para evitar poluir a análise com ruído estatístico.

## Faixas-alvo das margens (referência operacional da Lumina)

- **Margem Bruta:** alvo 43%–46% · ✓ saudável · ⚠ atenção fora da faixa por menos de 2pp · ⨯ alerta fora da faixa por mais de 2pp
- **Margem Operacional:** alvo 11%–14% · ✓ saudável · ⚠ atenção fora da faixa por menos de 2pp · ⨯ alerta fora da faixa por mais de 2pp
- **Margem Líquida:** alvo 10%–13% · ✓ saudável · ⚠ atenção fora da faixa por menos de 2pp · ⨯ alerta fora da faixa por mais de 2pp

## Estrutura do output

A análise deve ser produzida em **5 blocos sequenciais**:

### Bloco 1 — Executive Summary

3 frases curtas respondendo as perguntas que um CFO faz em 30 segundos:

```
**Como fomos:** [headline de 1 frase com o número que mais importa]
**O que se preocupar:** [top 2-3 pontos de atenção em frase única corrida]
**O que fazer:** [top 2-3 ações recomendadas em frase única corrida]
```

Esta é a parte mais importante da análise. Se o usuário ler nada além disso, precisa ter o panorama completo do mês.

### Bloco 2 — Análise das 3 margens principais

Para cada margem (Bruta → Operacional → Líquida), produzir:

```
### Margem [Nome] — [✓ ⚠ ou ⨯] [Diagnóstico em 1 palavra]

**Mês atual:** XX,X% · **Mês anterior:** XX,X% · **Variação:** ±X,Xpp

[Parágrafo de 2-4 linhas explicando o ROOT CAUSE da variação — o porquê,
não a descrição. Use contexto do setor de cosméticos brasileiro e da rede
Lumina (sazonalidade, mix de produtos, marca própria vs revenda, eventos
do mês como Black Friday, lançamentos, promoções).]

**Recomendação:** [1 ação acionável quando relevante. Omita se a margem
estiver saudável e dentro do esperado.]
```

### Bloco 3 — Movimentos materiais nas linhas do DRE

Listar variações relevantes (acima do threshold) em linhas específicas de Receita, CMV, Despesas Operacionais ou Financeiras. Para cada movimento material:

```
- **[Nome da linha]:** [valor atual] vs. [valor anterior] (variação ±R$ X.XXX.XXX,
±X,X%) — [explicação do root cause em 1-2 linhas]
```

Se nenhum movimento atender o threshold de materialidade, escreva:
*"Nenhum movimento material a destacar fora das margens já analisadas no Bloco 2."*

### Bloco 4 — O que esperar do próximo mês

Seção de 3-5 linhas com olhar prospectivo, considerando:

- Sazonalidade conhecida do setor de cosméticos no Brasil (datas comerciais relevantes do próximo mês)
- Tendências observadas no mês atual que tendem a continuar
- Riscos visíveis nos números atuais que podem se acentuar
- Oportunidades visíveis que podem ser capturadas

Foco em **antecipar perguntas** que a diretoria fará na próxima reunião.

### Bloco 5 — Pontos de atenção para o CFO

Lista bullet de **3 a 5 itens** de questões específicas que merecem investigação adicional ou conversa com times operacionais. Cada item deve ser:

- Específico (não genérico)
- Acionável (sugere com quem conversar ou o que verificar)
- Priorizado (mais importante primeiro)

Exemplo de formato:
```
- [ponto específico] → conversar com [time/responsável] para investigar [o que]
```

## Tom e estilo

- **Linguagem executiva:** clara, direta, sem jargão técnico desnecessário
- **Foco em decisão:** cada parágrafo deve ajudar o leitor a tomar uma decisão
- **Evitar dump de números:** os números já estão no DRE; a análise é o porquê
- **Tom da Lumina:** elegante, contido, alinhado à identidade minimalista oriental — frases enxutas, sem floreios
- **Português brasileiro executivo:** termos técnicos em inglês são aceitáveis quando padrão do mercado (root cause, variance, headline), mas o corpo da análise é em português

## Formatação

- Valores monetários em formato brasileiro: R$ 110.500.000 (com pontos como separador de milhar)
- Percentuais com uma casa decimal e vírgula: 43,8%
- Variações em pontos percentuais com sigla "pp": +1,2pp ou -0,8pp
- Símbolos de avaliação: ✓ saudável, ⚠ atenção, ⨯ alerta
- Negrito apenas nos labels, valores principais e diagnósticos (não no corpo da explicação)
- Sem emojis decorativos além dos símbolos de avaliação

## Exemplo de output completo

Para análise de outubro/2025 vs. setembro/2025 da Lumina:

```
# Análise Narrativa — Lumina · Outubro/2025

## Executive Summary

**Como fomos:** Receita Líquida cresceu 4,4% (R$ 85,0 mi vs. R$ 81,4 mi),
mas Margem Bruta caiu 1,2pp (43,8% vs. 45,0%) por aumento de descontos
pré-Black Friday e maior peso de revenda no mix.

**O que se preocupar:** compressão progressiva da margem bruta nos últimos
60 dias, aumento de 19% nas despesas com marketing antecipando Black Friday,
e despesas financeiras 19% acima do mês anterior.

**O que fazer:** revisar política de descontos com o time comercial antes
da Black Friday, validar com marketing se o ROI do investimento incremental
está sendo medido, e avaliar com tesouraria se vale antecipar capital de
giro do final do ano.

---

## Análise das 3 margens principais

### Margem Bruta — ⚠ Atenção

**Mês atual:** 43,8% · **Mês anterior:** 45,0% · **Variação:** -1,2pp

A queda da margem bruta combina dois efeitos: maior peso de revenda no mix
(linhas de margem menor cresceram mais que marca própria) e aumento de
descontos comerciais antecipando a Black Friday. O primeiro é estrutural
e tende a persistir; o segundo é sazonal e deve se reverter em janeiro.

**Recomendação:** revisar com o time comercial a política de descontos
pré-Black Friday — verificar se o desconto antecipado está canibalizando
vendas com margem cheia que aconteceriam no fim de novembro de qualquer
forma.

### Margem Operacional — ✓ Saudável

**Mês atual:** 11,4% · **Mês anterior:** 13,0% · **Variação:** -1,6pp

Apesar da queda de 1,6pp, a margem operacional permanece dentro da faixa-
alvo de 11%–14%. A queda é explicada principalmente pela compressão de
margem bruta (-1,2pp) e pelo aumento absoluto de despesas com marketing
(+R$ 1,3 mi vs. setembro) antecipando Black Friday.

**Recomendação:** validar com marketing se há tracking de ROI do
investimento incremental — o aumento de despesa só é justificável se a
receita capturada na Black Friday compensar.

### Margem Líquida — ⚠ Atenção

**Mês atual:** 10,0% · **Mês anterior:** 11,8% · **Variação:** -1,8pp

A margem líquida está no piso da faixa-alvo (10%–13%), pressionada pela
compressão das margens anteriores e por aumento de 19% nas despesas
financeiras (R$ 1,17 mi vs. R$ 980 mil) — efeito de maior antecipação de
recebíveis para fazer caixa pré-Black Friday.

**Recomendação:** avaliar com tesouraria se a antecipação está sendo feita
no melhor custo possível ou se cabe negociar taxa.

---

## Movimentos materiais nas linhas do DRE

- **CMV (Custo das Mercadorias Vendidas):** R$ 47,75 mi vs. R$ 44,78 mi
(+R$ 2,97 mi, +6,6%) — alta superior ao crescimento da receita, indicando
aumento do peso de revenda no mix e provisão maior por validade vencida
(R$ 680 mil em outubro vs. R$ 550 mil em setembro).

- **Despesa de Marketing:** R$ 3,13 mi vs. R$ 2,84 mi (+R$ 290 mil, +10,2%)
— investimento antecipado em mídia digital e influenciadoras para Black
Friday. Não há informação se está dentro do orçamento aprovado.

- **Despesas Financeiras:** R$ 1,17 mi vs. R$ 980 mil (+R$ 190 mil, +19,4%)
— aumento de antecipação de recebíveis e custo de hedge cambial subindo
em função de mais importações para a Black Friday.

---

## O que esperar do próximo mês

Novembro é o mês de maior receita do ano para o setor de cosméticos no
Brasil (Black Friday + início de campanhas de Natal). Esperamos crescimento
forte de receita, mas também:

- Margem bruta seguirá pressionada por descontos da Black Friday — provavelmente
ainda mais que outubro
- Despesa de marketing em pico (mídia, influenciadoras, material PDV)
- Despesas financeiras em alta (mais antecipação de recebíveis)
- Atenção redobrada com nível de estoque pós-Black Friday — risco de
sobreestoque em janeiro com vencimento próximo

A margem líquida pode cair abaixo da faixa-alvo em novembro — o que é
normal para o setor — mas deve se recuperar em dezembro/janeiro.

---

## Pontos de atenção para o CFO

- Investigar com o comercial se os descontos pré-Black Friday estão
canibalizando vendas com margem cheia → conversar com Diretoria Comercial
- Validar com marketing o ROI projetado da campanha Black Friday → solicitar
report de tracking semanal
- Verificar com tesouraria se a antecipação de recebíveis está no melhor
custo → pedir cotação alternativa em pelo menos 2 bancos
- Acompanhar nível de estoque por categoria considerando validade —
especialmente perfumaria importada → conversar com supply chain
- Monitorar same-store sales growth do canal físico após o pico da Black
Friday para entender efeito permanência → conversar com BI e operações
```

## Tratamento de erros

- **Se faltar o DRE do mês atual:** peça ao usuário para colar o DRE no chat ou gerar com a Skill "gerar-dre-lumina" antes de prosseguir
- **Se faltar o DRE do mês anterior:** verifique se há algum arquivo `.md` com DRE de referência no Project. Se não houver, peça para o usuário carregar como arquivo de contexto antes de prosseguir
- **Se as datas dos dois DREs não forem de meses consecutivos:** alerte o usuário e prossiga apenas se ele confirmar que quer comparar meses não consecutivos (a comparação ainda é útil, mas precisa ser explicitada)
- **Se a variação for nula em todas as margens:** produza ainda assim a análise destacando a estabilidade como característica relevante e olhando para movimentos absolutos de receita/despesas

## Não faça

- Não invente números que não estão nos DREs fornecidos
- Não compare com meses fora do escopo dos DREs fornecidos
- Não recomende ações que envolvam dados que não estão disponíveis (ex: "compare com o orçamento" se o orçamento não foi carregado)
- Não use linguagem técnica de contabilidade ou jargão de auditoria — o leitor é o CFO/diretoria, não o controller
- Não escreva análise para variações abaixo do materiality threshold — gera ruído
- Não inclua o DRE estruturado no output — esse é trabalho da Skill "gerar-dre-lumina"
- Não gere visualizações ou gráficos — esse é trabalho da Skill "gerar-painel-lumina" da AP04
