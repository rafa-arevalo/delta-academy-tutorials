---
name: organizar-lancamentos-lumina
description: Recebe uma planilha bruta de lançamentos contábeis da Lumina e devolve uma planilha estruturada com cada lançamento classificado conforme o plano de contas e a política de classificação carregados no Project Financeiro Lumina. Use sempre que o usuário enviar uma planilha de lançamentos da Lumina (vendas online, vendas físicas, custos, despesas) e pedir para organizar, classificar, categorizar ou estruturar os lançamentos no plano de contas.
---

# organizar-lancamentos-lumina

Skill que transforma uma planilha bruta de movimentações financeiras da Lumina em uma planilha estruturada com cada lançamento corretamente classificado dentro do plano de contas oficial da empresa.

**Filosofia:** classificação consistente mês a mês. A skill nunca inventa categorias — sempre usa as contas que existem no `plano-de-contas-lumina.md` e resolve ambiguidades aplicando as regras do `politica-classificacao-lancamentos.md`. Tudo carregado no Project Financeiro Lumina.

---

## PASSO 0 — Carregar os arquivos de contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia os 2 arquivos de contexto carregados no Project Financeiro Lumina:

1. **`plano-de-contas-lumina.md`** — lista oficial de todas as contas que existem na operação (Receitas, Deduções, CPV, Despesas Operacionais, Despesas Financeiras) com hierarquia de grupos e subgrupos
2. **`politica-classificacao-lancamentos.md`** — regras para resolver ambiguidades (frete, devoluções, permutas, rateio entre canais, etc.)

Se algum dos 2 arquivos não estiver disponível no Project, **pare e avise o usuário** — sem o plano de contas não há como classificar de forma consistente.

Após carregar, escreva uma linha curta confirmando:

> ✅ Plano de contas + política de classificação Lumina carregados.

---

## PASSO 1 — Receber e analisar a planilha

O usuário vai colar a planilha no chat ou anexar um arquivo `.xlsx` / `.csv`. Estrutura esperada de colunas (mas pode variar — adapte conforme necessário):

- `Data` — data do lançamento
- `Descrição` — descrição livre do que aconteceu (texto de 5 a 100 caracteres)
- `Valor (R$)` — valor monetário
- `Tipo` — Entrada / Saída
- `Forma de Pagamento` — PIX, Cartão, Boleto, TED, etc.
- `Centro de Custo` — pode vir vazio (será preenchido pela skill)
- `Conta do Plano` — pode vir vazio (será preenchido pela skill)

Se a planilha tiver colunas extras, **preserve-as**. Se faltar alguma das essenciais (Data, Descrição, Valor, Tipo), peça ao usuário para confirmar.

---

## PASSO 2 — Classificar cada lançamento

Para cada linha da planilha, faça em sequência:

### A. Identificar o tipo (Receita, Dedução, CPV, Despesa Op, Despesa Fin)

Olhe para `Descrição` + `Tipo` e identifique a categoria principal:

- **Entrada com descrição de "venda"** → Receita (e identifique canal: online, loja SP, loja RJ)
- **Saída com descrição de "compra de matéria-prima / embalagem / terceirização"** → CPV
- **Saída com descrição de "aluguel / folha / marketing / influenciador / frete / fulfillment / software / contabilidade / material"** → Despesa Operacional
- **Saída com descrição de "antecipação / IOF / tarifa / juros / gateway de pagamento"** → Despesa Financeira
- **Saída com descrição de "imposto / DAS / DARF / GPS"** → Dedução (impostos sobre vendas) OU Despesa Operacional dependendo do contexto (ver política)
- **Saída ou Entrada-estorno com descrição de "devolução"** → Dedução (devoluções)
- **Saída com descrição de "cupom promocional / cashback"** → Dedução (descontos comerciais)

### B. Mapear para a conta exata do plano de contas

Use **estritamente** os nomes de contas que existem no `plano-de-contas-lumina.md`. Não invente categorias.

Exemplo de mapeamento (depende do plano de contas real carregado):

| Descrição na planilha | Conta do Plano (mapeada) |
|---|---|
| "Vendas e-commerce - Pré-treino" | Receita Bruta > E-commerce > Pré-treino |
| "Vendas Loja SP - Semana 01" | Receita Bruta > Loja Física SP > Total |
| "Compra matéria-prima - Gelatina" | CPV > Matéria-prima > Insumos básicos |
| "Aluguel Loja SP" | Despesas Operacionais > Aluguel > Loja SP |
| "Pagamento influenciadora @..." | Despesas Operacionais > Marketing > Influenciadores |
| "Frete fulfillment e-commerce" | Despesas Operacionais > Logística > Fulfillment |
| "Antecipação de recebíveis" | Despesas Financeiras > Antecipação |
| "DAS Simples Nacional" | Deduções > Impostos sobre Vendas |
| "Devolução de produto" | Deduções > Devoluções |
| "Cupom promocional" | Deduções > Descontos Comerciais |

### C. Preencher o Centro de Custo

Para despesas que se aplicam a um canal específico:

- **Loja SP** — aluguel SP, folha alocada à SP
- **Loja RJ** — aluguel RJ, folha alocada à RJ
- **E-commerce** — frete fulfillment, plataforma e-commerce, mídia digital
- **Matriz/Geral** — folha administrativa, contabilidade, software ERP, despesas comuns

Use a **regra de rateio** definida em `politica-classificacao-lancamentos.md` para despesas que servem múltiplos canais.

### D. Resolver ambiguidades com a política

Lançamentos ambíguos devem ser resolvidos consultando a `politica-classificacao-lancamentos.md`. Exemplos comuns:

- **Frete:** se for fulfillment de pedidos online → Despesa Operacional · Logística · Fulfillment. Se for transferência entre lojas → CPV (custo de movimentação de estoque)
- **Influenciador via permuta:** se houve nota fiscal → Despesa Op · Marketing. Se foi permuta sem nota → Despesa Op · Marketing (com observação)
- **Cupom promocional:** sempre Dedução · Descontos Comerciais (não é despesa de marketing)
- **Devolução:** sempre Dedução · Devoluções (reduz a receita do mês)

---

## PASSO 3 — Devolver o output em 2 formatos

Sempre devolver em **2 formatos** ao usuário:

### Formato 1 — Resumo no chat (tabela markdown)

Mostre no chat um **resumo estruturado** dos resultados:

```
## ✅ Lançamentos organizados — Outubro/2025

**Total de lançamentos processados:** 60

### Distribuição por categoria

| Categoria | Qtd. lançamentos | Valor total (R$) |
|---|---|---|
| Receitas | 24 | R$ 935.480,00 |
| Deduções | 5 | R$ 49.880,00 |
| CPV | 10 | R$ 252.690,00 |
| Despesas Operacionais | 16 | R$ 218.640,00 |
| Despesas Financeiras | 5 | R$ 13.960,00 |

### Distribuição por canal (centro de custo)

| Centro de Custo | Qtd. lançamentos | Valor total (R$) |
|---|---|---|
| E-commerce | 18 | R$ 528.310,00 |
| Loja SP | 9 | R$ 175.770,00 |
| Loja RJ | 7 | R$ 133.480,00 |
| Matriz/Geral | 26 | R$ 632.230,00 |

### Observações da classificação

- N lançamentos exigiram aplicação de regra da política de classificação
- N lançamentos com ambiguidade foram classificados como [...] (justificativa)
- Verifique a planilha completa para o detalhamento linha a linha
```

### Formato 2 — Planilha estruturada (.xlsx artefato)

Use **code execution** para gerar uma planilha `.xlsx` com:

- **Todas as colunas originais** preservadas
- **Coluna "Centro de Custo"** preenchida
- **Coluna "Conta do Plano"** preenchida com a conta mapeada
- **Nova coluna "Justificativa"** (opcional, mas útil) com 1 linha curta explicando classificações ambíguas
- **Aba 2 "Resumo por Categoria"** com totais agregados (mesma tabela do resumo no chat)
- **Aba 3 "Resumo por Centro de Custo"** com totais agregados por canal

Aplique formatação visual minimalismo wellness premium da Lumina:
- Cabeçalho em verde-musgo `#5C7A5A` com texto branco quente `#FBF9F5`
- Linhas alternadas em branco quente
- Fonte Inter (ou similar sans-serif)
- Valores monetários no formato `R$ #.###,##`
- Bordas finas em verde-claro pálido `#D4DDC9`

Nome do arquivo: `lancamentos-lumina-classificados-{mes}-{ano}.xlsx`

---

## Tom e estilo

- Português brasileiro executivo, direto, profissional
- Tom alinhado com a energia wellness premium da Lumina (sofisticado, calmo, contido)
- Sem floreios — a classificação é uma operação técnica
- Quando houver ambiguidade, **explique brevemente** a decisão tomada (1-2 linhas no campo "Justificativa")

---

## Não faça

- Não invente categorias que não existem no `plano-de-contas-lumina.md`
- Não classifique sem consultar a `politica-classificacao-lancamentos.md` quando há ambiguidade
- Não altere os valores monetários originais — apenas adicione classificação
- Não altere a ordem ou estrutura das colunas originais — apenas preencha as vazias e adicione novas no fim
- Não pule lançamentos — todos devem ser classificados, mesmo que com observação
- Não retorne só o resumo no chat sem a planilha — sempre os 2 formatos

---

## Tratamento de erros

- **Plano de contas faltando no Project:** pare e peça ao usuário para carregar o `plano-de-contas-lumina.md` no Project antes de prosseguir
- **Política de classificação faltando:** alerte o usuário, mas continue (avisando que decisões ambíguas foram baseadas em best practice)
- **Planilha sem colunas essenciais:** peça ao usuário para confirmar a estrutura antes de processar
- **Lançamento com descrição muito vaga (ex: "Diversos", "Pagamento", sem mais info):** classifique como "A revisar — descrição insuficiente" e adicione à coluna Justificativa

---

## Exemplo de comportamento esperado

**Input do usuário:**
> "Anexei a planilha de lançamentos brutos de outubro/2025 da Lumina. Por favor organize tudo no plano de contas."

**Output esperado:**

1. Linha de confirmação: "✅ Plano de contas + política de classificação Lumina carregados."
2. Resumo no chat com tabelas de distribuição (formato 1 acima)
3. Artefato `.xlsx` gerado com a planilha completa estruturada (formato 2 acima)
4. Mensagem final curta: *"Planilha pronta. Você pode usar este arquivo como input para a próxima Skill (geração de DRE)."*
